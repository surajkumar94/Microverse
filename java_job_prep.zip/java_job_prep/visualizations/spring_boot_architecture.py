import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.path as path
import numpy as np

# Set figure size and DPI for high quality
plt.figure(figsize=(14, 10), dpi=150)

# Define colors
spring_green = '#6db33f'
spring_dark = '#3f7320'
light_blue = '#5bc0de'
dark_blue = '#337ab9'
light_gray = '#f8f9fa'
medium_gray = '#e9ecef'
dark_gray = '#343a40'
orange = '#f0ad4e'
red = '#d9534f'

# Main background
ax = plt.gca()
ax.add_patch(patches.Rectangle((0, 0), 10, 8, facecolor=light_gray, edgecolor='none', alpha=0.5))

# Spring Boot Application
app_rect = patches.Rectangle((1, 1), 8, 6.5, facecolor='white', edgecolor=spring_green, 
                            linewidth=2, alpha=0.9, zorder=1)
ax.add_patch(app_rect)

# Spring Boot Banner
banner = patches.Rectangle((1, 6.5), 8, 1, facecolor=spring_green, edgecolor='none', alpha=0.9, zorder=2)
ax.add_patch(banner)
plt.text(5, 7, 'Spring Boot Application', ha='center', va='center', fontsize=16, 
         fontweight='bold', color='white', zorder=3)

# Auto-configuration
auto_config = patches.Rectangle((1.5, 5.5), 7, 0.7, facecolor=spring_dark, edgecolor='none', 
                               alpha=0.8, zorder=2, linewidth=1)
ax.add_patch(auto_config)
plt.text(5, 5.85, 'Auto-Configuration', ha='center', va='center', fontsize=14, 
         fontweight='bold', color='white', zorder=3)

# Spring Core Container
core_container = patches.Rectangle((1.5, 3.5), 7, 1.5, facecolor=light_blue, edgecolor=dark_blue, 
                                  alpha=0.8, zorder=2, linewidth=1)
ax.add_patch(core_container)
plt.text(5, 4.75, 'Spring Core Container', ha='center', va='center', fontsize=14, 
         fontweight='bold', color='white', zorder=3)

# Core components
components = [
    ('Beans', 2, 4, 1.5, 0.5),
    ('Context', 3.75, 4, 1.5, 0.5),
    ('SpEL', 5.5, 4, 1.5, 0.5),
    ('Core', 7.25, 4, 1, 0.5)
]

for name, x, y, w, h in components:
    ax.add_patch(patches.Rectangle((x, y), w, h, facecolor=dark_blue, edgecolor='none', 
                                  alpha=0.9, zorder=3))
    plt.text(x + w/2, y + h/2, name, ha='center', va='center', fontsize=10, 
             color='white', zorder=4)

# Spring Boot Starters
starters = patches.Rectangle((1.5, 2.5), 3.25, 0.7, facecolor=orange, edgecolor='none', 
                            alpha=0.8, zorder=2)
ax.add_patch(starters)
plt.text(3.125, 2.85, 'Spring Boot Starters', ha='center', va='center', fontsize=12, 
         fontweight='bold', color='white', zorder=3)

# Embedded Servers
servers = patches.Rectangle((5.25, 2.5), 3.25, 0.7, facecolor=orange, edgecolor='none', 
                           alpha=0.8, zorder=2)
ax.add_patch(servers)
plt.text(6.875, 2.85, 'Embedded Servers', ha='center', va='center', fontsize=12, 
         fontweight='bold', color='white', zorder=3)

# Application Layers
layers = [
    ('Web Layer (Controllers)', 1.5, 1.8, 7, 0.5),
    ('Service Layer', 1.5, 1.3, 7, 0.5),
    ('Data Access Layer (Repositories)', 1.5, 0.8, 7, 0.5)
]

for name, x, y, w, h in layers:
    ax.add_patch(patches.Rectangle((x, y), w, h, facecolor=medium_gray, edgecolor=dark_gray, 
                                  alpha=0.8, zorder=2, linewidth=1))
    plt.text(x + w/2, y + h/2, name, ha='center', va='center', fontsize=12, 
             fontweight='bold', color=dark_gray, zorder=3)

# External Components
# Database
db_x, db_y = 9.5, 0.8
db_width, db_height = 0.8, 0.5
ax.add_patch(patches.Rectangle((db_x-0.1, db_y-0.1), db_width+0.2, db_height+0.2, 
                              facecolor='white', edgecolor=dark_gray, linewidth=1, zorder=2))
ax.add_patch(patches.Rectangle((db_x, db_y), db_width, db_height, 
                              facecolor=medium_gray, edgecolor=dark_gray, linewidth=1, zorder=3))
plt.text(db_x + db_width/2, db_y + db_height/2, 'Database', ha='center', va='center', 
         fontsize=10, color=dark_gray, zorder=4)

# Arrow to database
arrow = patches.FancyArrowPatch((8.5, 1.05), (9.4, 1.05), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=4)
ax.add_patch(arrow)

# External Services
ext_x, ext_y = 9.5, 1.8
ext_width, ext_height = 0.8, 0.5
ax.add_patch(patches.Rectangle((ext_x-0.1, ext_y-0.1), ext_width+0.2, ext_height+0.2, 
                              facecolor='white', edgecolor=dark_gray, linewidth=1, zorder=2))
ax.add_patch(patches.Rectangle((ext_x, ext_y), ext_width, ext_height, 
                              facecolor=medium_gray, edgecolor=dark_gray, linewidth=1, zorder=3))
plt.text(ext_x + ext_width/2, ext_y + ext_height/2, 'External\nServices', ha='center', va='center', 
         fontsize=8, color=dark_gray, zorder=4)

# Arrow to external services
arrow = patches.FancyArrowPatch((8.5, 2.05), (9.4, 2.05), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=4)
ax.add_patch(arrow)

# Client/Browser
client_x, client_y = 5, 8.5
client_width, client_height = 1, 0.5
ax.add_patch(patches.Rectangle((client_x-0.5, client_y-0.25), client_width, client_height, 
                              facecolor=medium_gray, edgecolor=dark_gray, linewidth=1, zorder=3))
plt.text(client_x, client_y, 'Client/Browser', ha='center', va='center', 
         fontsize=10, color=dark_gray, zorder=4)

# Arrow from client to application
arrow = patches.FancyArrowPatch((5, 8.2), (5, 7.6), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=4)
ax.add_patch(arrow)

# Actuator
actuator_x, actuator_y = 0.5, 4
actuator_width, actuator_height = 0.8, 1
ax.add_patch(patches.Rectangle((actuator_x-0.1, actuator_y-0.1), actuator_width+0.2, actuator_height+0.2, 
                              facecolor='white', edgecolor=red, linewidth=1, zorder=2))
ax.add_patch(patches.Rectangle((actuator_x, actuator_y), actuator_width, actuator_height, 
                              facecolor=red, edgecolor='none', alpha=0.8, linewidth=1, zorder=3))
plt.text(actuator_x + actuator_width/2, actuator_y + actuator_height/2, 'Actuator\nEndpoints', 
         ha='center', va='center', fontsize=8, color='white', zorder=4)

# Arrow from application to actuator
arrow = patches.FancyArrowPatch((1.4, 4.5), (0.9, 4.5), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<-', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=4)
ax.add_patch(arrow)

# Add title and annotations
plt.title('Spring Boot Architecture Overview', fontsize=18, pad=20)

# Add annotations
annotations = [
    (5, 6.2, "Auto-Configuration: Automatically configures your application based on dependencies"),
    (5, 5.2, "Spring Core: Fundamental Spring Framework components"),
    (3.125, 2.2, "Starters: Pre-configured dependency descriptors"),
    (6.875, 2.2, "Servers: Tomcat, Jetty, Undertow"),
    (5, 0.4, "Application Layers: Separation of concerns in your application")
]

for x, y, text in annotations:
    plt.annotate(text, xy=(x, y), xytext=(x, y-0.2),
                 ha='center', va='top', fontsize=8, color=dark_gray,
                 bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.7))

# Remove axes
plt.axis('off')
plt.xlim(0, 10.5)
plt.ylim(0, 9)

# Save the figure
plt.tight_layout()
plt.savefig('/home/ubuntu/java_job_prep/visualizations/spring_boot_architecture.png', dpi=300, bbox_inches='tight')
plt.close()

print("Spring Boot architecture visualization created successfully!")
