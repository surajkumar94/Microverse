import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.path as path
import numpy as np

# Set figure size and DPI for high quality
plt.figure(figsize=(16, 12), dpi=150)

# Define colors
spring_green = '#6db33f'
spring_dark = '#3f7320'
light_blue = '#5bc0de'
dark_blue = '#337ab9'
light_gray = '#f8f9fa'
medium_gray = '#e9ecef'
dark_gray = '#343a40'
orange = '#f0ad4e'
red = '#d9534f'
purple = '#9b59b6'
yellow = '#f1c40f'
teal = '#1abc9c'

# Main background
ax = plt.gca()
ax.add_patch(patches.Rectangle((0, 0), 14, 10, facecolor=light_gray, edgecolor='none', alpha=0.5))

# API Gateway
gateway_rect = patches.Rectangle((5.5, 8), 3, 1, facecolor=dark_blue, edgecolor='none', 
                                alpha=0.9, zorder=2)
ax.add_patch(gateway_rect)
plt.text(7, 8.5, 'API Gateway', ha='center', va='center', fontsize=14, 
         fontweight='bold', color='white', zorder=3)

# Service Discovery
discovery_rect = patches.Rectangle((1, 8), 3, 1, facecolor=purple, edgecolor='none', 
                                  alpha=0.9, zorder=2)
ax.add_patch(discovery_rect)
plt.text(2.5, 8.5, 'Service Discovery', ha='center', va='center', fontsize=14, 
         fontweight='bold', color='white', zorder=3)

# Config Server
config_rect = patches.Rectangle((10, 8), 3, 1, facecolor=teal, edgecolor='none', 
                               alpha=0.9, zorder=2)
ax.add_patch(config_rect)
plt.text(11.5, 8.5, 'Config Server', ha='center', va='center', fontsize=14, 
         fontweight='bold', color='white', zorder=3)

# Microservices
services = [
    ('User Service', 1.5, 5.5, 2.5, 1.5, spring_green),
    ('Product Service', 4.5, 5.5, 2.5, 1.5, spring_green),
    ('Order Service', 7.5, 5.5, 2.5, 1.5, spring_green),
    ('Payment Service', 10.5, 5.5, 2.5, 1.5, spring_green),
    ('Notification Service', 3, 3, 2.5, 1.5, spring_green),
    ('Analytics Service', 9, 3, 2.5, 1.5, spring_green)
]

for name, x, y, w, h, color in services:
    # Spring Boot App container
    ax.add_patch(patches.Rectangle((x-0.1, y-0.1), w+0.2, h+0.2, facecolor='white', 
                                  edgecolor=color, linewidth=2, alpha=0.9, zorder=1))
    # Service banner
    ax.add_patch(patches.Rectangle((x, y+h-0.4), w, 0.4, facecolor=color, 
                                  edgecolor='none', alpha=0.9, zorder=2))
    plt.text(x + w/2, y+h-0.2, name, ha='center', va='center', fontsize=12, 
             fontweight='bold', color='white', zorder=3)
    
    # Spring Boot logo
    plt.text(x + w/2, y + h/2 - 0.2, 'Spring Boot\nMicroservice', ha='center', va='center', 
             fontsize=10, fontweight='bold', color=dark_gray, zorder=3)
    
    # Database for each service
    db_x, db_y = x + w/2 - 0.3, y - 0.7
    db_width, db_height = 0.6, 0.4
    ax.add_patch(patches.Rectangle((db_x, db_y), db_width, db_height, 
                                  facecolor=medium_gray, edgecolor=dark_gray, linewidth=1, zorder=3))
    plt.text(db_x + db_width/2, db_y + db_height/2, 'DB', ha='center', va='center', 
             fontsize=8, color=dark_gray, zorder=4)
    
    # Arrow to database
    arrow = patches.FancyArrowPatch((x + w/2, y), (x + w/2, y - 0.3), 
                                   connectionstyle="arc3,rad=0", 
                                   arrowstyle='<->', 
                                   mutation_scale=10, 
                                   linewidth=1, 
                                   color=dark_gray, zorder=4)
    ax.add_patch(arrow)

# Message Broker
broker_rect = patches.Rectangle((6, 1), 2.5, 1, facecolor=orange, edgecolor='none', 
                               alpha=0.9, zorder=2)
ax.add_patch(broker_rect)
plt.text(7.25, 1.5, 'Message Broker\n(Kafka/RabbitMQ)', ha='center', va='center', fontsize=12, 
         fontweight='bold', color='white', zorder=3)

# Client/Browser
client_x, client_y = 7, 10
client_width, client_height = 1, 0.5
ax.add_patch(patches.Rectangle((client_x-0.5, client_y-0.25), client_width, client_height, 
                              facecolor=medium_gray, edgecolor=dark_gray, linewidth=1, zorder=3))
plt.text(client_x, client_y, 'Client/Browser', ha='center', va='center', 
         fontsize=10, color=dark_gray, zorder=4)

# Arrow from client to API Gateway
arrow = patches.FancyArrowPatch((7, 9.7), (7, 9), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=4)
ax.add_patch(arrow)

# Arrows from API Gateway to services
for name, x, y, w, h, color in services[:4]:  # Only top row services connect directly to gateway
    arrow = patches.FancyArrowPatch((7, 8), (x + w/2, y + h), 
                                   connectionstyle="arc3,rad=0.1", 
                                   arrowstyle='<->', 
                                   mutation_scale=15, 
                                   linewidth=1.5, 
                                   color=dark_gray, zorder=1)
    ax.add_patch(arrow)

# Arrows between services (selected connections to show communication)
# Order to Payment
arrow = patches.FancyArrowPatch((8.75, 6), (10.5, 6), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=1)
ax.add_patch(arrow)

# Order to User
arrow = patches.FancyArrowPatch((7.5, 6), (4, 6), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=1)
ax.add_patch(arrow)

# Order to Notification
arrow = patches.FancyArrowPatch((7.5, 5.5), (5.5, 3.75), 
                               connectionstyle="arc3,rad=-0.2", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=1)
ax.add_patch(arrow)

# Payment to Notification
arrow = patches.FancyArrowPatch((10.5, 5.5), (5.5, 3.75), 
                               connectionstyle="arc3,rad=0.2", 
                               arrowstyle='<->', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=1)
ax.add_patch(arrow)

# Arrows to Message Broker
for name, x, y, w, h, color in services:
    if name in ['Order Service', 'Payment Service', 'Notification Service']:
        arrow = patches.FancyArrowPatch((x + w/2, y), (7.25, 2), 
                                       connectionstyle="arc3,rad=0.1", 
                                       arrowstyle='<->', 
                                       mutation_scale=15, 
                                       linewidth=1.5, 
                                       color=orange, zorder=1)
        ax.add_patch(arrow)

# Arrows to Service Discovery
for name, x, y, w, h, color in services:
    arrow = patches.FancyArrowPatch((x + w/4, y + h), (2.5, 8), 
                                   connectionstyle="arc3,rad=-0.1", 
                                   arrowstyle='->', 
                                   mutation_scale=10, 
                                   linewidth=1, 
                                   color=purple, zorder=1, alpha=0.6)
    ax.add_patch(arrow)

# Arrows to Config Server
for name, x, y, w, h, color in services:
    arrow = patches.FancyArrowPatch((x + 3*w/4, y + h), (11.5, 8), 
                                   connectionstyle="arc3,rad=0.1", 
                                   arrowstyle='<-', 
                                   mutation_scale=10, 
                                   linewidth=1, 
                                   color=teal, zorder=1, alpha=0.6)
    ax.add_patch(arrow)

# Circuit Breaker
circuit_x, circuit_y = 13, 6
circuit_width, circuit_height = 0.8, 0.8
ax.add_patch(patches.Rectangle((circuit_x-0.1, circuit_y-0.1), circuit_width+0.2, circuit_height+0.2, 
                              facecolor='white', edgecolor=red, linewidth=1, zorder=2))
ax.add_patch(patches.Rectangle((circuit_x, circuit_y), circuit_width, circuit_height, 
                              facecolor=red, edgecolor='none', alpha=0.8, linewidth=1, zorder=3))
plt.text(circuit_x + circuit_width/2, circuit_y + circuit_height/2, 'Circuit\nBreaker', 
         ha='center', va='center', fontsize=8, color='white', zorder=4)

# Arrow from services to circuit breaker
arrow = patches.FancyArrowPatch((13, 6.4), (12.5, 6.4), 
                               connectionstyle="arc3,rad=0", 
                               arrowstyle='<-', 
                               mutation_scale=15, 
                               linewidth=1.5, 
                               color=dark_gray, zorder=4)
ax.add_patch(arrow)

# Monitoring
monitor_x, monitor_y = 13, 3
monitor_width, monitor_height = 0.8, 0.8
ax.add_patch(patches.Rectangle((monitor_x-0.1, monitor_y-0.1), monitor_width+0.2, monitor_height+0.2, 
                              facecolor='white', edgecolor=yellow, linewidth=1, zorder=2))
ax.add_patch(patches.Rectangle((monitor_x, monitor_y), monitor_width, monitor_height, 
                              facecolor=yellow, edgecolor='none', alpha=0.8, linewidth=1, zorder=3))
plt.text(monitor_x + monitor_width/2, monitor_y + monitor_height/2, 'Monitoring', 
         ha='center', va='center', fontsize=8, color=dark_gray, zorder=4)

# Arrows from services to monitoring
for name, x, y, w, h, color in services:
    if name in ['User Service', 'Order Service', 'Analytics Service']:
        arrow = patches.FancyArrowPatch((x + w, y + h/2), (13, 3.4), 
                                       connectionstyle="arc3,rad=0.1", 
                                       arrowstyle='->', 
                                       mutation_scale=10, 
                                       linewidth=1, 
                                       color=yellow, zorder=1, alpha=0.6)
        ax.add_patch(arrow)

# Add title
plt.title('Microservices Architecture Overview', fontsize=20, pad=20)

# Add annotations
annotations = [
    (7, 9.3, "Client communicates with microservices through API Gateway"),
    (2.5, 7.5, "Service Discovery: Registers and locates service instances"),
    (11.5, 7.5, "Config Server: Centralized configuration management"),
    (7, 7, "Microservices: Independent Spring Boot applications"),
    (7.25, 0.7, "Message Broker: Asynchronous communication between services"),
    (13.4, 6.4, "Circuit Breaker: Prevents cascading failures"),
    (13.4, 3.4, "Monitoring: Tracks health and performance")
]

for x, y, text in annotations:
    plt.annotate(text, xy=(x, y), xytext=(x, y-0.2),
                 ha='center', va='top', fontsize=8, color=dark_gray,
                 bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.7))

# Remove axes
plt.axis('off')
plt.xlim(0, 14)
plt.ylim(0, 10.5)

# Save the figure
plt.tight_layout()
plt.savefig('/home/ubuntu/java_job_prep/visualizations/microservices_architecture.png', dpi=300, bbox_inches='tight')
plt.close()

print("Microservices architecture visualization created successfully!")
