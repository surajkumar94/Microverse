# Microservices Concepts Guide

## Introduction to Microservices

Microservices architecture is an approach to developing a single application as a suite of small, independently deployable services, each running in its own process and communicating with lightweight mechanisms, often an HTTP API. These services are built around business capabilities and independently deployable by fully automated deployment machinery.

### Evolution from Monolithic Architecture

Traditional monolithic applications are built as a single, autonomous unit where:
- The application is a single codebase
- All components are tightly coupled
- The entire application is deployed as one unit
- Scaling requires replicating the entire application

In contrast, microservices architecture breaks down the application into a collection of loosely coupled services where:
- Each service has a specific business function
- Services are independently deployable
- Services can be implemented using different technologies
- Services can scale independently

## Core Principles of Microservices

### 1. Single Responsibility

Each microservice should have a single responsibility and do one thing well. This aligns with the Single Responsibility Principle from SOLID design principles.

```java
// User Service - Responsible only for user management
@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    @Override
    public User createUser(User user) {
        // Logic for creating a user
        return userRepository.save(user);
    }
    
    @Override
    public User getUserById(Long id) {
        // Logic for retrieving a user
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }
}
```

### 2. Autonomy

Microservices should be autonomous and self-contained. They should be able to function independently without relying on other services for their core functionality.

### 3. Decentralization

Microservices architecture promotes decentralized governance and data management. Each service can have its own database schema and technology stack.

```java
// Order Service with its own database configuration
@Configuration
@EnableJpaRepositories(basePackages = "com.example.orderservice.repository")
@EntityScan(basePackages = "com.example.orderservice.model")
public class OrderDatabaseConfig {
    
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(
            EntityManagerFactoryBuilder builder, DataSource dataSource) {
        return builder
                .dataSource(dataSource)
                .packages("com.example.orderservice.model")
                .persistenceUnit("orders")
                .build();
    }
}
```

### 4. Domain-Driven Design

Microservices are typically organized around business capabilities and domains, not technical functions.

```java
// Domain model in Order Service
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private Long userId;
    
    @Column(nullable = false)
    private BigDecimal totalAmount;
    
    @Enumerated(EnumType.STRING)
    private OrderStatus status;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "order")
    private List<OrderItem> items = new ArrayList<>();
    
    // Getters and setters
}
```

### 5. Resilience

Microservices should be designed to handle failures gracefully. If one service fails, it should not bring down the entire system.

```java
// Using Circuit Breaker pattern with Resilience4j
@Service
public class OrderServiceImpl implements OrderService {
    private final RestTemplate restTemplate;
    
    public OrderServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    
    @CircuitBreaker(name = "paymentService", fallbackMethod = "paymentServiceFallback")
    public PaymentResponse processPayment(PaymentRequest request) {
        return restTemplate.postForObject(
            "http://payment-service/api/payments", 
            request, 
            PaymentResponse.class
        );
    }
    
    public PaymentResponse paymentServiceFallback(PaymentRequest request, Exception e) {
        // Fallback logic when payment service is down
        return new PaymentResponse(false, "Payment service unavailable");
    }
}
```

## Microservices Architecture Components

### 1. API Gateway

The API Gateway is a server that acts as an API front-end, receiving API requests, enforcing throttling and security policies, passing requests to the back-end service, and then passing the response back to the requester.

```java
// Spring Cloud Gateway configuration
@Configuration
public class GatewayConfig {
    
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
            .route("user_service_route", r -> r
                .path("/api/users/**")
                .filters(f -> f
                    .rewritePath("/api/users/(?<segment>.*)", "/${segment}")
                    .addRequestHeader("X-Gateway-Source", "api-gateway"))
                .uri("lb://user-service"))
            .route("order_service_route", r -> r
                .path("/api/orders/**")
                .filters(f -> f
                    .rewritePath("/api/orders/(?<segment>.*)", "/${segment}")
                    .addRequestHeader("X-Gateway-Source", "api-gateway"))
                .uri("lb://order-service"))
            .build();
    }
}
```

### 2. Service Discovery

Service Discovery allows services to find and communicate with each other without hardcoding hostname and port. When a service wants to call another service, it can query the Service Discovery component to locate the available instances.

```java
// Eureka Server configuration
@SpringBootApplication
@EnableEurekaServer
public class DiscoveryServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(DiscoveryServiceApplication.class, args);
    }
}

// Eureka Client configuration in a microservice
@SpringBootApplication
@EnableDiscoveryClient
public class OrderServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
}
```

### 3. Config Server

The Config Server provides a centralized configuration for all microservices. It allows you to manage configuration for all environments and services in a single place.

```java
// Config Server configuration
@SpringBootApplication
@EnableConfigServer
public class ConfigServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
    }
}

// application.yml for Config Server
server:
  port: 8888
spring:
  cloud:
    config:
      server:
        git:
          uri: https://github.com/myorg/config-repo
          search-paths: '{application}'
```

### 4. Circuit Breaker

The Circuit Breaker pattern prevents cascading failures in distributed systems. It monitors for failures and prevents the application from performing operations that are likely to fail.

```java
// Resilience4j Circuit Breaker configuration
@Configuration
public class CircuitBreakerConfig {
    
    @Bean
    public Customizer<Resilience4jCircuitBreakerFactory> defaultCustomizer() {
        return factory -> factory.configureDefault(id -> new Resilience4jConfigBuilder(id)
            .timeLimiterConfig(TimeLimiterConfig.custom()
                .timeoutDuration(Duration.ofSeconds(4))
                .build())
            .circuitBreakerConfig(CircuitBreakerConfig.ofDefaults())
            .build());
    }
}
```

### 5. Message Broker

Message Brokers enable asynchronous communication between microservices, which helps in building loosely coupled systems.

```java
// Kafka Producer configuration
@Configuration
public class KafkaProducerConfig {
    
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    @Bean
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }
    
    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}

// Kafka Consumer configuration
@Configuration
public class KafkaConsumerConfig {
    
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "order-group");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        return new DefaultKafkaConsumerFactory<>(props);
    }
    
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
}
```

### 6. Distributed Tracing

Distributed Tracing helps track requests as they flow through distributed systems, making it easier to identify bottlenecks and troubleshoot issues.

```java
// Spring Cloud Sleuth and Zipkin configuration
@SpringBootApplication
@EnableZipkinServer
public class TracingServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(TracingServiceApplication.class, args);
    }
}

// application.yml for a microservice
spring:
  sleuth:
    sampler:
      probability: 1.0
  zipkin:
    base-url: http://zipkin-server:9411/
```

## Communication Patterns in Microservices

### 1. Synchronous Communication (REST, gRPC)

Synchronous communication involves direct point-to-point communication between services, typically using REST APIs or gRPC.

```java
// REST Controller in Order Service
@RestController
@RequestMapping("/api/orders")
public class OrderController {
    
    private final OrderService orderService;
    
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest request) {
        Order order = orderService.createOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(order);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        Order order = orderService.getOrderById(id);
        return ResponseEntity.ok(order);
    }
}

// REST Client in another service
@Service
public class OrderClientImpl implements OrderClient {
    
    private final RestTemplate restTemplate;
    
    public OrderClientImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    
    @Override
    public Order getOrderById(Long id) {
        return restTemplate.getForObject(
            "http://order-service/api/orders/{id}", 
            Order.class, 
            id
        );
    }
}
```

### 2. Asynchronous Communication (Message Queues)

Asynchronous communication involves sending messages through a message broker without waiting for a response.

```java
// Kafka Producer in Order Service
@Service
public class OrderEventPublisher {
    
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    
    public OrderEventPublisher(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }
    
    public void publishOrderCreatedEvent(Order order) throws JsonProcessingException {
        OrderEvent event = new OrderEvent("ORDER_CREATED", order);
        String payload = objectMapper.writeValueAsString(event);
        kafkaTemplate.send("order-events", payload);
    }
}

// Kafka Consumer in Notification Service
@Service
public class OrderEventConsumer {
    
    private final NotificationService notificationService;
    private final ObjectMapper objectMapper;
    
    public OrderEventConsumer(NotificationService notificationService, ObjectMapper objectMapper) {
        this.notificationService = notificationService;
        this.objectMapper = objectMapper;
    }
    
    @KafkaListener(topics = "order-events", groupId = "notification-group")
    public void consume(String message) throws JsonProcessingException {
        OrderEvent event = objectMapper.readValue(message, OrderEvent.class);
        
        if ("ORDER_CREATED".equals(event.getType())) {
            Order order = event.getOrder();
            notificationService.sendOrderConfirmation(order);
        }
    }
}
```

### 3. Event-Driven Architecture

Event-Driven Architecture involves producing and consuming events. Services publish events when they change state, and other services subscribe to those events.

```java
// Event publishing with Spring Cloud Stream
@Configuration
public class StreamConfig {
    
    @Bean
    public Function<Order, OrderCreatedEvent> orderProcessor() {
        return order -> new OrderCreatedEvent(order.getId(), order.getUserId(), order.getTotalAmount());
    }
}

// application.yml for Spring Cloud Stream
spring:
  cloud:
    stream:
      function:
        definition: orderProcessor
      bindings:
        orderProcessor-out-0:
          destination: order-events
          content-type: application/json
```

## Data Management in Microservices

### 1. Database per Service

Each microservice has its own database, which ensures loose coupling and independence.

```java
// Order Service database configuration
@Configuration
@EnableJpaRepositories
@EntityScan("com.example.orderservice.model")
public class OrderDatabaseConfig {
    
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }
}

// application.yml for Order Service
spring:
  datasource:
    url: jdbc:mysql://order-db:3306/orderdb
    username: order_user
    password: order_pass
  jpa:
    hibernate:
      ddl-auto: update
```

### 2. CQRS (Command Query Responsibility Segregation)

CQRS separates read and write operations, allowing for optimized data models for each operation.

```java
// Command (Write) model
@Service
public class OrderCommandService {
    
    private final OrderRepository orderRepository;
    private final OrderEventPublisher eventPublisher;
    
    public OrderCommandService(OrderRepository orderRepository, OrderEventPublisher eventPublisher) {
        this.orderRepository = orderRepository;
        this.eventPublisher = eventPublisher;
    }
    
    @Transactional
    public Order createOrder(OrderRequest request) {
        Order order = new Order();
        order.setUserId(request.getUserId());
        order.setTotalAmount(request.getTotalAmount());
        order.setStatus(OrderStatus.CREATED);
        
        Order savedOrder = orderRepository.save(order);
        eventPublisher.publishOrderCreatedEvent(savedOrder);
        
        return savedOrder;
    }
}

// Query (Read) model
@Service
public class OrderQueryService {
    
    private final OrderReadRepository orderReadRepository;
    
    public OrderQueryService(OrderReadRepository orderReadRepository) {
        this.orderReadRepository = orderReadRepository;
    }
    
    public OrderSummary getOrderSummary(Long orderId) {
        return orderReadRepository.findOrderSummaryById(orderId)
            .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }
    
    public List<OrderSummary> getOrdersByUserId(Long userId) {
        return orderReadRepository.findOrderSummariesByUserId(userId);
    }
}
```

### 3. Saga Pattern

The Saga pattern manages distributed transactions across multiple services, ensuring data consistency.

```java
// Choreography-based Saga
@Service
public class OrderSagaService {
    
    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    
    public OrderSagaService(OrderRepository orderRepository, 
                           KafkaTemplate<String, String> kafkaTemplate,
                           ObjectMapper objectMapper) {
        this.orderRepository = orderRepository;
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }
    
    @Transactional
    public Order createOrder(OrderRequest request) throws JsonProcessingException {
        // Create and save the order with PENDING status
        Order order = new Order();
        order.setUserId(request.getUserId());
        order.setTotalAmount(request.getTotalAmount());
        order.setStatus(OrderStatus.PENDING);
        
        Order savedOrder = orderRepository.save(order);
        
        // Publish event to start the saga
        OrderCreatedEvent event = new OrderCreatedEvent(
            savedOrder.getId(), 
            savedOrder.getUserId(),
            savedOrder.getTotalAmount()
        );
        
        kafkaTemplate.send("order-created", objectMapper.writeValueAsString(event));
        
        return savedOrder;
    }
    
    @KafkaListener(topics = "payment-completed")
    public void handlePaymentCompleted(String message) throws JsonProcessingException {
        PaymentCompletedEvent event = objectMapper.readValue(message, PaymentCompletedEvent.class);
        
        Order order = orderRepository.findById(event.getOrderId())
            .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        
        order.setStatus(OrderStatus.PAID);
        orderRepository.save(order);
        
        // Publish event to continue the saga
        OrderPaidEvent orderPaidEvent = new OrderPaidEvent(order.getId());
        kafkaTemplate.send("order-paid", objectMapper.writeValueAsString(orderPaidEvent));
    }
    
    @KafkaListener(topics = "payment-failed")
    public void handlePaymentFailed(String message) throws JsonProcessingException {
        PaymentFailedEvent event = objectMapper.readValue(message, PaymentFailedEvent.class);
        
        Order order = orderRepository.findById(event.getOrderId())
            .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        
        order.setStatus(OrderStatus.PAYMENT_FAILED);
        orderRepository.save(order);
    }
}
```

## Testing Microservices

### 1. Unit Testing

Testing individual components in isolation.

```java
@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private OrderEventPublisher eventPublisher;
    
    @InjectMocks
    private OrderServiceImpl orderService;
    
    @Test
    public void testCreateOrder() {
        // Arrange
        OrderRequest request = new OrderRequest(1L, new BigDecimal("100.00"));
        Order order = new Order();
        order.setId(1L);
        order.setUserId(1L);
        order.setTotalAmount(new BigDecimal("100.00"));
        order.setStatus(OrderStatus.CREATED);
        
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        
        // Act
        Order result = orderService.createOrder(request);
        
        // Assert
        assertEquals(1L, result.getId());
        assertEquals(OrderStatus.CREATED, result.getStatus());
        verify(orderRepository).save(any(Order.class));
        verify(eventPublisher).publishOrderCreatedEvent(order);
    }
}
```

### 2. Integration Testing

Testing the interaction between components.

```java
@SpringBootTest
public class OrderRepositoryIntegrationTest {
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Test
    public void testSaveAndFindOrder() {
        // Arrange
        Order order = new Order();
        order.setUserId(1L);
        order.setTotalAmount(new BigDecimal("100.00"));
        order.setStatus(OrderStatus.CREATED);
        
        // Act
        Order savedOrder = orderRepository.save(order);
        Optional<Order> foundOrder = orderRepository.findById(savedOrder.getId());
        
        // Assert
        assertTrue(foundOrder.isPresent());
        assertEquals(savedOrder.getId(), foundOrder.get().getId());
        assertEquals(OrderStatus.CREATED, foundOrder.get().getStatus());
    }
}
```

### 3. Contract Testing

Ensuring that services can communicate with each other as expected.

```java
// Consumer-Driven Contract Testing with Spring Cloud Contract
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureStubRunner(
    ids = {"com.example:order-service:+:stubs:8080"},
    stubsMode = StubRunnerProperties.StubsMode.LOCAL
)
public class OrderClientContractTest {
    
    @Autowired
    private OrderClient orderClient;
    
    @Test
    public void testGetOrderById() {
        // Act
        Order order = orderClient.getOrderById(1L);
        
        // Assert
        assertNotNull(order);
        assertEquals(1L, order.getId());
        assertEquals(OrderStatus.CREATED, order.getStatus());
    }
}
```

### 4. End-to-End Testing

Testing the entire system as a whole.

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class OrderEndToEndTest {
    
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Test
    public void testCreateAndGetOrder() {
        // Arrange
        OrderRequest request = new OrderRequest(1L, new BigDecimal("100.00"));
        
        // Act - Create Order
        ResponseEntity<Order> createResponse = restTemplate.postForEntity(
            "/api/orders", 
            request, 
            Order.class
        );
        
        // Assert - Create Order
        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());
        assertNotNull(createResponse.getBody());
        
        Long orderId = createResponse.getBody().getId();
        
        // Act - Get Order
        ResponseEntity<Order> getResponse = restTemplate.getForEntity(
            "/api/orders/{id}", 
            Order.class, 
            orderId
        );
        
        // Assert - Get Order
        assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        assertNotNull(getResponse.getBody());
        assertEquals(orderId, getResponse.getBody().getId());
    }
}
```

## Deployment and Scaling

### 1. Containerization with Docker

Packaging microservices as Docker containers for consistent deployment.

```dockerfile
# Dockerfile for a Spring Boot microservice
FROM openjdk:11-jre-slim

WORKDIR /app

COPY target/order-service-0.0.1-SNAPSHOT.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 2. Orchestration with Kubernetes

Managing containerized microservices with Kubernetes for scaling and resilience.

```yaml
# Kubernetes Deployment for Order Service
apiVersion: apps/v1
kind: Deployment
metadata:
  name: order-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: order-service
  template:
    metadata:
      labels:
        app: order-service
    spec:
      containers:
      - name: order-service
        image: myregistry/order-service:latest
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "prod"
        - name: SPRING_DATASOURCE_URL
          value: "jdbc:mysql://mysql-service:3306/orderdb"
        resources:
          limits:
            cpu: "500m"
            memory: "512Mi"
          requests:
            cpu: "200m"
            memory: "256Mi"
        readinessProbe:
          httpGet:
            path: /actuator/health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /actuator/health
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 15

# Kubernetes Service for Order Service
apiVersion: v1
kind: Service
metadata:
  name: order-service
spec:
  selector:
    app: order-service
  ports:
  - port: 80
    targetPort: 8080
  type: ClusterIP
```

### 3. CI/CD Pipeline

Automating the build, test, and deployment process for microservices.

```yaml
# Jenkins Pipeline for a microservice
pipeline {
    agent any
    
    stages {
        stage('Build') {
            steps {
                sh 'mvn clean package'
            }
        }
        
        stage('Test') {
            steps {
                sh 'mvn test'
            }
        }
        
        stage('Docker Build') {
            steps {
                sh 'docker build -t myregistry/order-service:${BUILD_NUMBER} .'
            }
        }
        
        stage('Docker Push') {
            steps {
                withCredentials([string(credentialsId: 'docker-hub', variable: 'DOCKER_HUB_CREDS')]) {
                    sh 'docker login -u myusername -p ${DOCKER_HUB_CREDS}'
                    sh 'docker push myregistry/order-service:${BUILD_NUMBER}'
                }
            }
        }
        
        stage('Deploy to Kubernetes') {
            steps {
                sh 'kubectl set image deployment/order-service order-service=myregistry/order-service:${BUILD_NUMBER}'
            }
        }
    }
}
```

## Monitoring and Observability

### 1. Health Checks

Implementing health checks to monitor the status of microservices.

```java
@Component
public class OrderServiceHealthIndicator implements HealthIndicator {
    
    private final OrderRepository orderRepository;
    
    public OrderServiceHealthIndicator(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
    
    @Override
    public Health health() {
        try {
            // Check if database is accessible
            orderRepository.count();
            return Health.up().withDetail("database", "accessible").build();
        } catch (Exception e) {
            return Health.down().withDetail("database", "inaccessible").withException(e).build();
        }
    }
}
```

### 2. Metrics Collection

Collecting metrics to monitor performance and resource usage.

```java
@RestController
@RequestMapping("/api/orders")
public class OrderController {
    
    private final OrderService orderService;
    private final MeterRegistry meterRegistry;
    
    public OrderController(OrderService orderService, MeterRegistry meterRegistry) {
        this.orderService = orderService;
        this.meterRegistry = meterRegistry;
    }
    
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest request) {
        Timer.Sample sample = Timer.start(meterRegistry);
        
        Order order = orderService.createOrder(request);
        
        sample.stop(meterRegistry.timer("order.creation.time"));
        meterRegistry.counter("order.created").increment();
        
        return ResponseEntity.status(HttpStatus.CREATED).body(order);
    }
}
```

### 3. Distributed Tracing

Tracing requests as they flow through multiple microservices.

```java
// application.yml for Spring Cloud Sleuth and Zipkin
spring:
  sleuth:
    sampler:
      probability: 1.0
  zipkin:
    base-url: http://zipkin-server:9411/
```

### 4. Centralized Logging

Aggregating logs from all microservices for easier troubleshooting.

```java
// application.yml for Logback and ELK Stack
logging:
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n"
  level:
    root: INFO
    org.springframework.web: INFO
    com.example.orderservice: DEBUG
  file:
    name: /var/log/order-service.log
```

## Security in Microservices

### 1. Authentication and Authorization

Implementing security measures to protect microservices.

```java
// Spring Security configuration
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .csrf().disable()
            .authorizeRequests()
                .antMatchers("/actuator/**").permitAll()
                .antMatchers("/api/**").authenticated()
                .anyRequest().authenticated()
            .and()
            .oauth2ResourceServer()
                .jwt();
    }
}
```

### 2. API Gateway Security

Implementing security at the API Gateway level.

```java
// Spring Cloud Gateway security configuration
@Configuration
public class GatewaySecurityConfig {
    
    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        http
            .csrf().disable()
            .authorizeExchange()
                .pathMatchers("/actuator/**").permitAll()
                .pathMatchers("/api/**").authenticated()
                .anyExchange().authenticated()
            .and()
            .oauth2Login()
            .and()
            .oauth2ResourceServer()
                .jwt();
        
        return http.build();
    }
}
```

### 3. Inter-Service Communication Security

Securing communication between microservices.

```java
// RestTemplate with client certificate
@Configuration
public class RestTemplateConfig {
    
    @Bean
    public RestTemplate restTemplate() throws Exception {
        SSLContext sslContext = SSLContextBuilder
            .create()
            .loadKeyMaterial(
                new ClassPathResource("keystore.jks").getURL(),
                "keystorepass".toCharArray(),
                "keypass".toCharArray()
            )
            .loadTrustMaterial(
                new ClassPathResource("truststore.jks").getURL(),
                "truststorepass".toCharArray()
            )
            .build();
        
        HttpClient httpClient = HttpClients.custom()
            .setSSLContext(sslContext)
            .build();
        
        HttpComponentsClientHttpRequestFactory requestFactory = 
            new HttpComponentsClientHttpRequestFactory(httpClient);
        
        return new RestTemplate(requestFactory);
    }
}
```

## Microservices Best Practices

### 1. Design for Failure

Assume that services will fail and design your system to handle failures gracefully.

```java
// Resilience4j Circuit Breaker
@Service
public class OrderServiceImpl implements OrderService {
    
    private final RestTemplate restTemplate;
    private final CircuitBreakerFactory circuitBreakerFactory;
    
    public OrderServiceImpl(RestTemplate restTemplate, CircuitBreakerFactory circuitBreakerFactory) {
        this.restTemplate = restTemplate;
        this.circuitBreakerFactory = circuitBreakerFactory;
    }
    
    @Override
    public PaymentResponse processPayment(PaymentRequest request) {
        CircuitBreaker circuitBreaker = circuitBreakerFactory.create("payment");
        
        return circuitBreaker.run(
            () -> restTemplate.postForObject(
                "http://payment-service/api/payments", 
                request, 
                PaymentResponse.class
            ),
            throwable -> fallbackPayment(request, throwable)
        );
    }
    
    private PaymentResponse fallbackPayment(PaymentRequest request, Throwable throwable) {
        // Log the error
        log.error("Payment service call failed", throwable);
        
        // Return a fallback response
        return new PaymentResponse(false, "Payment service unavailable");
    }
}
```

### 2. Implement Proper Logging

Implement consistent and meaningful logging across all microservices.

```java
@Service
public class OrderServiceImpl implements OrderService {
    
    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);
    
    private final OrderRepository orderRepository;
    
    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
    
    @Override
    public Order createOrder(OrderRequest request) {
        log.info("Creating order for user: {}", request.getUserId());
        
        try {
            Order order = new Order();
            order.setUserId(request.getUserId());
            order.setTotalAmount(request.getTotalAmount());
            order.setStatus(OrderStatus.CREATED);
            
            Order savedOrder = orderRepository.save(order);
            
            log.info("Order created successfully: {}", savedOrder.getId());
            
            return savedOrder;
        } catch (Exception e) {
            log.error("Failed to create order for user: {}", request.getUserId(), e);
            throw e;
        }
    }
}
```

### 3. Use Asynchronous Communication When Possible

Prefer asynchronous communication to reduce coupling between services.

```java
// Asynchronous communication with Spring Cloud Stream
@Configuration
public class StreamConfig {
    
    @Bean
    public Consumer<OrderEvent> orderEventConsumer() {
        return event -> {
            if ("ORDER_CREATED".equals(event.getType())) {
                // Process the order created event
                log.info("Received order created event: {}", event.getOrderId());
                // Business logic here
            }
        };
    }
}

// application.yml for Spring Cloud Stream
spring:
  cloud:
    stream:
      function:
        definition: orderEventConsumer
      bindings:
        orderEventConsumer-in-0:
          destination: order-events
          group: notification-service
```

### 4. Implement API Versioning

Version your APIs to allow for evolution without breaking existing clients.

```java
@RestController
@RequestMapping("/api/v1/orders")
public class OrderControllerV1 {
    
    private final OrderService orderService;
    
    public OrderControllerV1(OrderService orderService) {
        this.orderService = orderService;
    }
    
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest request) {
        Order order = orderService.createOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(order);
    }
}

@RestController
@RequestMapping("/api/v2/orders")
public class OrderControllerV2 {
    
    private final OrderServiceV2 orderService;
    
    public OrderControllerV2(OrderServiceV2 orderService) {
        this.orderService = orderService;
    }
    
    @PostMapping
    public ResponseEntity<OrderResponseV2> createOrder(@RequestBody OrderRequestV2 request) {
        OrderResponseV2 response = orderService.createOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
```

### 5. Implement Rate Limiting

Protect your services from being overwhelmed by too many requests.

```java
// Rate limiting with Spring Cloud Gateway
@Configuration
public class GatewayConfig {
    
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
            .route("order_service_route", r -> r
                .path("/api/orders/**")
                .filters(f -> f
                    .requestRateLimiter(c -> c
                        .setRateLimiter(redisRateLimiter())
                        .setKeyResolver(userKeyResolver()))
                    .rewritePath("/api/orders/(?<segment>.*)", "/${segment}"))
                .uri("lb://order-service"))
            .build();
    }
    
    @Bean
    public RedisRateLimiter redisRateLimiter() {
        return new RedisRateLimiter(10, 20);
    }
    
    @Bean
    KeyResolver userKeyResolver() {
        return exchange -> Mono.just(
            Optional.ofNullable(exchange.getRequest().getHeaders().getFirst("X-User-Id"))
                .orElse("anonymous")
        );
    }
}
```

## Conclusion

Microservices architecture offers numerous benefits, including scalability, flexibility, and resilience. However, it also introduces complexity in terms of deployment, monitoring, and inter-service communication. By understanding the core principles and best practices outlined in this guide, you'll be well-equipped to design, implement, and maintain microservices-based applications effectively.

Remember that microservices architecture is not a one-size-fits-all solution. It's important to evaluate whether this architecture style is appropriate for your specific use case, considering factors such as team size, application complexity, and organizational structure.

This guide covered the fundamental concepts of microservices, including architecture components, communication patterns, data management, testing, deployment, monitoring, security, and best practices. By mastering these concepts, you'll be well-prepared for your job interviews and future work as a Java developer in a microservices environment.
