# Spring Boot Core Concepts Guide

## Introduction to Spring Boot

Spring Boot is an extension of the Spring Framework that simplifies the process of building production-ready applications. It takes an opinionated view of the Spring platform and third-party libraries, allowing you to get started with minimum fuss. Most Spring Boot applications need very little Spring configuration.

### Key Features of Spring Boot

1. **Auto-configuration**: Automatically configures your application based on the dependencies you have added
2. **Standalone**: Creates stand-alone Spring applications that can be started using `java -jar`
3. **Opinionated**: Provides opinionated 'starter' dependencies to simplify build configuration
4. **Production-ready**: Includes embedded servers, security, metrics, health checks, and externalized configuration

## Spring Boot Architecture

Spring Boot follows a layered architecture that builds upon the core Spring Framework. The architecture consists of several key components:

### 1. Spring Boot Auto-configuration

Auto-configuration is one of the most powerful features of Spring Boot. It attempts to automatically configure your Spring application based on the jar dependencies you have added. For example, if HSQLDB is on your classpath, and you have not manually configured any database connection beans, then Spring Boot auto-configures an in-memory database.

```java
@SpringBootApplication
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

The `@SpringBootApplication` annotation is equivalent to using `@Configuration`, `@EnableAutoConfiguration`, and `@ComponentScan` with their default attributes.

### 2. Spring Boot Starters

Starters are a set of convenient dependency descriptors that you can include in your application. They provide a one-stop shop for all the Spring and related technologies you need without having to search for sample code and copy-paste dependencies.

For example, if you want to use Spring and JPA for database access, include the `spring-boot-starter-data-jpa` dependency in your project.

```xml
<!-- Maven dependency -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
```

```gradle
// Gradle dependency
implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
```

Common Spring Boot starters include:
- `spring-boot-starter-web`: For building web applications, including RESTful applications using Spring MVC
- `spring-boot-starter-data-jpa`: For using Spring Data JPA with Hibernate
- `spring-boot-starter-security`: For using Spring Security
- `spring-boot-starter-test`: For testing Spring Boot applications

### 3. Spring Boot Embedded Servers

Spring Boot includes support for embedded Tomcat, Jetty, and Undertow servers. You don't need to deploy your application to a web server - it's packaged as a standalone executable jar file with an embedded server.

```java
@SpringBootApplication
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

When you run this application, it starts an embedded web server (Tomcat by default) on port 8080.

### 4. Spring Boot Actuator

Spring Boot Actuator provides production-ready features to help you monitor and manage your application. It offers several endpoints to expose operational information about your running application – health, metrics, info, dump, env, etc.

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

Once added, you can access endpoints like:
- `/actuator/health`: Shows application health information
- `/actuator/metrics`: Shows metrics information
- `/actuator/info`: Displays arbitrary application info

## Spring Boot Core Components

### 1. Spring Core Container

The Core Container provides the fundamental functionality of the Spring Framework. Its main components include:

#### 1.1 Beans

The Spring Bean is the fundamental unit in Spring applications. Beans are objects that are instantiated, assembled, and managed by the Spring IoC container.

```java
@Component
public class UserService {
    // Service methods
}
```

#### 1.2 Context

The Spring Context is a configuration file that provides context information to the Spring framework. It provides services like JNDI lookup, EJB integration, email, validation, and scheduling functionality.

```java
ApplicationContext context = SpringApplication.run(MyApplication.class, args);
UserService userService = context.getBean(UserService.class);
```

#### 1.3 SpEL (Spring Expression Language)

SpEL is a powerful expression language that supports querying and manipulating an object graph at runtime.

```java
@Value("#{systemProperties['user.region']}")
private String region;
```

#### 1.4 Core

The Core module provides the fundamental parts of the framework, including IoC and Dependency Injection features.

### 2. Application Layers

A typical Spring Boot application is divided into several layers:

#### 2.1 Web Layer (Controllers)

The web layer handles HTTP requests and responses. It's implemented using Spring MVC controllers.

```java
@RestController
@RequestMapping("/api/users")
public class UserController {
    
    private final UserService userService;
    
    public UserController(UserService userService) {
        this.userService = userService;
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.findById(id));
    }
    
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(userService.save(user));
    }
}
```

#### 2.2 Service Layer

The service layer contains business logic and calls the data access layer.

```java
@Service
public class UserServiceImpl implements UserService {
    
    private final UserRepository userRepository;
    
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    @Override
    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }
    
    @Override
    public User save(User user) {
        return userRepository.save(user);
    }
}
```

#### 2.3 Data Access Layer (Repositories)

The data access layer interacts with the database using Spring Data repositories.

```java
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByLastName(String lastName);
}
```

## Spring Boot Configuration

### 1. Properties and YAML Configuration

Spring Boot allows you to externalize your configuration using properties files, YAML files, environment variables, and command-line arguments.

#### application.properties
```properties
# Server configuration
server.port=8080
server.servlet.context-path=/api

# Database configuration
spring.datasource.url=jdbc:mysql://localhost:3306/mydb
spring.datasource.username=root
spring.datasource.password=password
spring.jpa.hibernate.ddl-auto=update

# Logging configuration
logging.level.org.springframework=INFO
logging.level.com.myapp=DEBUG
```

#### application.yml
```yaml
server:
  port: 8080
  servlet:
    context-path: /api

spring:
  datasource:
    url: jdbc:mysql://localhost:3306/mydb
    username: root
    password: password
  jpa:
    hibernate:
      ddl-auto: update

logging:
  level:
    org.springframework: INFO
    com.myapp: DEBUG
```

### 2. Profiles

Spring Boot supports different environments through profiles. You can use profiles to separate configuration for different environments (dev, test, prod).

```properties
# application-dev.properties
server.port=8080
spring.datasource.url=jdbc:h2:mem:testdb

# application-prod.properties
server.port=80
spring.datasource.url=jdbc:mysql://production-server:3306/mydb
```

To activate a profile:
```java
@SpringBootApplication
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(MyApplication.class);
        app.setAdditionalProfiles("dev");
        app.run(args);
    }
}
```

Or using command line:
```bash
java -jar myapp.jar --spring.profiles.active=dev
```

## Dependency Injection in Spring Boot

Dependency Injection (DI) is a design pattern that removes the dependency from the programming code so that it can be easy to manage and test the application. Spring Boot supports three types of dependency injection:

### 1. Constructor Injection (Recommended)

```java
@Service
public class UserServiceImpl implements UserService {
    
    private final UserRepository userRepository;
    
    // Constructor injection
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    // Service methods
}
```

### 2. Setter Injection

```java
@Service
public class UserServiceImpl implements UserService {
    
    private UserRepository userRepository;
    
    // Setter injection
    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    // Service methods
}
```

### 3. Field Injection (Not Recommended)

```java
@Service
public class UserServiceImpl implements UserService {
    
    // Field injection
    @Autowired
    private UserRepository userRepository;
    
    // Service methods
}
```

## Spring Boot Annotations

Spring Boot provides a rich set of annotations to simplify development:

### Core Annotations

- `@SpringBootApplication`: Combines `@Configuration`, `@EnableAutoConfiguration`, and `@ComponentScan`
- `@Configuration`: Indicates that a class declares one or more `@Bean` methods
- `@Bean`: Indicates that a method produces a bean to be managed by the Spring container
- `@Component`: Indicates that a class is a Spring component
- `@Service`: Specialization of `@Component` for service layer
- `@Repository`: Specialization of `@Component` for data access layer
- `@Controller`: Specialization of `@Component` for presentation layer (MVC controller)
- `@RestController`: Combines `@Controller` and `@ResponseBody`

### Web Annotations

- `@RequestMapping`: Maps HTTP requests to handler methods
- `@GetMapping`: Shortcut for `@RequestMapping(method = RequestMethod.GET)`
- `@PostMapping`: Shortcut for `@RequestMapping(method = RequestMethod.POST)`
- `@PutMapping`: Shortcut for `@RequestMapping(method = RequestMethod.PUT)`
- `@DeleteMapping`: Shortcut for `@RequestMapping(method = RequestMethod.DELETE)`
- `@PathVariable`: Binds a method parameter to a URI template variable
- `@RequestParam`: Binds a method parameter to a web request parameter
- `@RequestBody`: Binds a method parameter to the body of the web request

### Data Access Annotations

- `@Entity`: Specifies that the class is an entity
- `@Table`: Specifies the primary table for the annotated entity
- `@Id`: Specifies the primary key of an entity
- `@GeneratedValue`: Specifies the generation strategy for the primary key
- `@Column`: Specifies the mapped column for a persistent property
- `@Transactional`: Declares that a method should be executed within a transaction

## Spring Boot Testing

Spring Boot provides excellent support for testing your application:

### 1. Unit Testing

```java
@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
    
    @Mock
    private UserRepository userRepository;
    
    @InjectMocks
    private UserServiceImpl userService;
    
    @Test
    public void testFindById() {
        // Arrange
        User user = new User(1L, "John", "Doe", "john@example.com");
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        
        // Act
        User result = userService.findById(1L);
        
        // Assert
        assertEquals(user.getId(), result.getId());
        assertEquals(user.getEmail(), result.getEmail());
        verify(userRepository, times(1)).findById(1L);
    }
}
```

### 2. Integration Testing

```java
@SpringBootTest
public class UserControllerIntegrationTest {
    
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Test
    public void testGetUserById() {
        // Act
        ResponseEntity<User> response = restTemplate.getForEntity("/api/users/1", User.class);
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
    }
}
```

### 3. Web Layer Testing

```java
@WebMvcTest(UserController.class)
public class UserControllerTest {
    
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private UserService userService;
    
    @Test
    public void testGetUserById() throws Exception {
        // Arrange
        User user = new User(1L, "John", "Doe", "john@example.com");
        when(userService.findById(1L)).thenReturn(user);
        
        // Act & Assert
        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.email").value("john@example.com"));
    }
}
```

## Spring Boot Best Practices

### 1. Use Constructor Injection

Constructor injection makes dependencies explicit and supports immutable objects.

```java
@Service
public class UserServiceImpl implements UserService {
    
    private final UserRepository userRepository;
    private final EmailService emailService;
    
    public UserServiceImpl(UserRepository userRepository, EmailService emailService) {
        this.userRepository = userRepository;
        this.emailService = emailService;
    }
    
    // Service methods
}
```

### 2. Use Configuration Properties

For complex configuration, use `@ConfigurationProperties` instead of `@Value`.

```java
@Configuration
@ConfigurationProperties(prefix = "app.mail")
public class MailProperties {
    
    private String host;
    private int port;
    private String username;
    private String password;
    
    // Getters and setters
}
```

### 3. Use Appropriate Response Status

Use appropriate HTTP status codes in your REST APIs.

```java
@RestController
@RequestMapping("/api/users")
public class UserController {
    
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public User createUser(@RequestBody User user) {
        return userService.save(user);
    }
    
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteUser(@PathVariable Long id) {
        userService.deleteById(id);
    }
}
```

### 4. Implement Exception Handling

Use `@ControllerAdvice` to handle exceptions globally.

```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleResourceNotFoundException(ResourceNotFoundException ex) {
        return new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
    }
    
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleGenericException(Exception ex) {
        return new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected error occurred");
    }
}
```

### 5. Use Validation

Validate input data using Bean Validation.

```java
@RestController
@RequestMapping("/api/users")
public class UserController {
    
    @PostMapping
    public ResponseEntity<User> createUser(@Valid @RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(userService.save(user));
    }
}

@Entity
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "First name is required")
    private String firstName;
    
    @NotBlank(message = "Last name is required")
    private String lastName;
    
    @Email(message = "Email should be valid")
    @NotBlank(message = "Email is required")
    private String email;
    
    // Getters and setters
}
```

## Conclusion

Spring Boot simplifies the development of Spring applications by providing a set of conventions, opinions, and tools. It allows developers to focus on business logic rather than boilerplate configuration. Understanding the core concepts of Spring Boot is essential for building robust, maintainable, and scalable applications.

This guide covered the fundamental concepts of Spring Boot, including its architecture, core components, configuration, dependency injection, annotations, testing, and best practices. By mastering these concepts, you'll be well-equipped to develop Spring Boot applications efficiently and effectively.
