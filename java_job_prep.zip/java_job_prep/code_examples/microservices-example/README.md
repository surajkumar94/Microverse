# Microservices Example Project Structure

This directory contains a simplified microservices architecture example with the following services:

1. **API Gateway Service** - Routes requests to appropriate microservices
2. **Discovery Service** - Service registry for microservice discovery
3. **Config Service** - Centralized configuration management
4. **User Service** - Manages user data and authentication
5. **Product Service** - Manages product catalog
6. **Order Service** - Handles order processing

Each service is a separate Spring Boot application that demonstrates microservices patterns and best practices.

## How to Use This Example

This example is structured to show the key components of a microservices architecture. In a real-world scenario, you would:

1. Build each service using Maven or Gradle
2. Run the Discovery Service first
3. Run the Config Service next
4. Start the remaining services in any order
5. Access the system through the API Gateway

## Key Concepts Demonstrated

- Service Discovery with Eureka
- Centralized Configuration with Spring Cloud Config
- API Gateway pattern with Spring Cloud Gateway
- Circuit Breaker pattern with Resilience4j
- Event-driven communication with Kafka
- Database per Service pattern
- Distributed tracing with Spring Cloud Sleuth

## Service Dependencies

```
                    +----------------+
                    |                |
                    | API Gateway    |
                    |                |
                    +-------+--------+
                            |
                            v
              +-------------+--------------+
              |                            |
              |     Discovery Service      |
              |                            |
              +---+----------+----------+--+
                  |          |          |
                  v          v          v
    +-------------+--+ +-----+------+ +-+------------+
    |                | |            | |              |
    | User Service   | | Product    | | Order        |
    |                | | Service    | | Service      |
    +----------------+ +------------+ +--------------+
```
