package com.example.springbootexample.repository;

import com.example.springbootexample.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Derived query method - Spring Data JPA will generate the implementation
    Optional<User> findByEmail(String email);
    
    // Derived query method with multiple conditions
    List<User> findByLastNameOrderByFirstNameAsc(String lastName);
    
    // Custom query using JPQL
    @Query("SELECT u FROM User u WHERE u.firstName LIKE %:name% OR u.lastName LIKE %:name%")
    List<User> findByName(@Param("name") String name);
    
    // Native SQL query
    @Query(value = "SELECT * FROM users WHERE LOWER(email) LIKE LOWER(CONCAT('%', :domain, '%'))", 
           nativeQuery = true)
    List<User> findByEmailDomain(@Param("domain") String domain);
    
    // Check if user exists
    boolean existsByEmail(String email);
}
