# Spring Boot and Microservices Interview Questions and Answers

## Spring Boot Interview Questions

### 1. What is Spring Boot and what are its main features?

**Answer:** Spring Boot is an extension of the Spring Framework that simplifies the process of building production-ready applications. It takes an opinionated view of the Spring platform and third-party libraries, allowing developers to get started with minimum fuss.

**Main features:**
- **Auto-configuration**: Automatically configures your application based on the dependencies you have added
- **Standalone**: Creates stand-alone Spring applications that can be started using `java -jar`
- **Opinionated defaults**: Provides opinionated 'starter' dependencies to simplify build configuration
- **Production-ready**: Includes embedded servers, security, metrics, health checks, and externalized configuration
- **No code generation and no XML configuration**: Reduces boilerplate code and configuration

### 2. What is Spring Boot Auto-configuration?

**Answer:** Auto-configuration is one of the most powerful features of Spring Boot. It attempts to automatically configure your Spring application based on the jar dependencies you have added. For example, if HSQLDB is on your classpath, and you have not manually configured any database connection beans, then Spring Boot auto-configures an in-memory database.

Auto-configuration is implemented using the `@EnableAutoConfiguration` annotation (which is included in `@SpringBootApplication`). It's non-invasive, meaning you can define your own configuration to replace specific parts of the auto-configuration.

### 3. What are Spring Boot Starters?

**Answer:** Spring Boot Starters are a set of convenient dependency descriptors that you can include in your application. They provide a one-stop shop for all the Spring and related technologies you need without having to search for sample code and copy-paste dependencies.

For example, if you want to use Spring and JPA for database access, include the `spring-boot-starter-data-jpa` dependency in your project. Starters contain a lot of dependencies that you would need to get a project up and running quickly and with a consistent, supported set of managed transitive dependencies.

Common starters include:
- `spring-boot-starter-web`: For building web applications, including RESTful applications using Spring MVC
- `spring-boot-starter-data-jpa`: For using Spring Data JPA with Hibernate
- `spring-boot-starter-security`: For using Spring Security
- `spring-boot-starter-test`: For testing Spring Boot applications

### 4. What is the difference between `@SpringBootApplication` and `@EnableAutoConfiguration`?

**Answer:** `@SpringBootApplication` is a convenience annotation that combines three annotations:
1. `@Configuration`: Tags the class as a source of bean definitions for the application context
2. `@EnableAutoConfiguration`: Enables Spring Boot's auto-configuration mechanism
3. `@ComponentScan`: Enables component scanning in the package where the application is located

`@EnableAutoConfiguration` is just one part of `@SpringBootApplication`. It tells Spring Boot to "guess" how you want to configure Spring, based on the jar dependencies that you have added. For example, if HSQLDB is on the classpath, and you have not manually configured any database connection beans, then Spring Boot auto-configures an in-memory database.

### 5. How can you externalize configuration in Spring Boot?

**Answer:** Spring Boot allows you to externalize your configuration using:

1. **Properties files**: `application.properties` or `application.yml` files in various locations:
   - Externally in a `/config` subdirectory of the current directory
   - Externally in the current directory
   - In a classpath `/config` package
   - In the classpath root

2. **Environment variables**: Spring Boot will convert environment variables to properties
   
3. **Command-line arguments**: You can pass properties as command-line arguments

4. **Profile-specific properties**: `application-{profile}.properties` or `application-{profile}.yml`

5. **@ConfigurationProperties**: For type-safe configuration properties

The order listed above is also the order of precedence (command-line arguments override environment variables, which override properties files).

### 6. What is Spring Boot Actuator?

**Answer:** Spring Boot Actuator is a sub-project of Spring Boot that adds production-ready features to your application. It provides several endpoints to monitor and manage your application:

- `/actuator/health`: Shows application health information
- `/actuator/info`: Displays arbitrary application info
- `/actuator/metrics`: Shows metrics information
- `/actuator/env`: Exposes properties from Spring's ConfigurableEnvironment
- `/actuator/mappings`: Displays a list of all @RequestMapping paths
- `/actuator/beans`: Displays a complete list of all Spring beans in your application

These endpoints can be secured using Spring Security. Actuator is particularly useful for monitoring and managing applications in production.

### 7. How do you implement security in a Spring Boot application?

**Answer:** Security in Spring Boot applications is typically implemented using Spring Security. Here's a basic approach:

1. Add the Spring Security starter dependency:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
```

2. Create a security configuration class:
```java
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
                .antMatchers("/public/**").permitAll()
                .anyRequest().authenticated()
                .and()
            .formLogin()
                .loginPage("/login")
                .permitAll()
                .and()
            .logout()
                .permitAll();
    }
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth
            .inMemoryAuthentication()
                .withUser("user").password("{noop}password").roles("USER")
                .and()
                .withUser("admin").password("{noop}admin").roles("ADMIN");
    }
}
```

For production applications, you would typically use a database-backed user store with encrypted passwords, OAuth2/JWT for stateless authentication, or integrate with an identity provider.

### 8. What is the difference between JPA and Hibernate?

**Answer:** JPA (Java Persistence API) is a specification that describes the management of relational data in Java applications. It's just a specification, not an implementation.

Hibernate is an implementation of the JPA specification. It's an ORM (Object-Relational Mapping) tool that provides a framework for mapping Java objects to database tables and vice versa.

The relationship is similar to the relationship between JDBC (specification) and JDBC drivers (implementation). Hibernate implements the JPA specification but also provides additional features beyond the specification.

Using JPA makes your code more portable since you're programming to an interface rather than a specific implementation. You can switch from Hibernate to another JPA implementation (like EclipseLink) with minimal changes to your code.

### 9. What is the difference between `@Controller` and `@RestController`?

**Answer:** 
- `@Controller` is a Spring MVC annotation that marks a class as a web controller, capable of handling HTTP requests. When used with `@ResponseBody` on methods, it returns the data directly in the response body.

- `@RestController` is a specialized version of `@Controller` that combines `@Controller` and `@ResponseBody`. It's used for RESTful web services where every method returns data directly rather than relying on view resolvers.

Example with `@Controller`:
```java
@Controller
public class UserController {
    @GetMapping("/users/{id}")
    @ResponseBody
    public User getUser(@PathVariable Long id) {
        return userService.findById(id);
    }
}
```

Equivalent with `@RestController`:
```java
@RestController
public class UserController {
    @GetMapping("/users/{id}")
    public User getUser(@PathVariable Long id) {
        return userService.findById(id);
    }
}
```

### 10. What are the different types of dependency injection in Spring?

**Answer:** Spring supports three types of dependency injection:

1. **Constructor Injection**: Dependencies are provided through a class constructor.
```java
@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    
    // Constructor injection
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}
```

2. **Setter Injection**: Dependencies are provided through setter methods.
```java
@Service
public class UserServiceImpl implements UserService {
    private UserRepository userRepository;
    
    // Setter injection
    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}
```

3. **Field Injection**: Dependencies are injected directly into fields.
```java
@Service
public class UserServiceImpl implements UserService {
    // Field injection
    @Autowired
    private UserRepository userRepository;
}
```

Constructor injection is generally preferred because:
- It ensures that required dependencies are not null (immutability)
- It makes testing easier
- It prevents circular dependencies at compile time

### 11. How do you handle exceptions in a Spring Boot REST application?

**Answer:** In a Spring Boot REST application, exceptions can be handled using:

1. **@ExceptionHandler**: Method-level annotation to handle exceptions in specific controller classes.
```java
@RestController
public class UserController {
    @ExceptionHandler(UserNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleUserNotFound(UserNotFoundException ex) {
        return new ErrorResponse("USER_NOT_FOUND", ex.getMessage());
    }
}
```

2. **@ControllerAdvice/@RestControllerAdvice**: Class-level annotation to handle exceptions globally across all controllers.
```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(UserNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleUserNotFound(UserNotFoundException ex) {
        return new ErrorResponse("USER_NOT_FOUND", ex.getMessage());
    }
    
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleGenericException(Exception ex) {
        return new ErrorResponse("INTERNAL_ERROR", "An unexpected error occurred");
    }
}
```

3. **ResponseStatusException**: Throw this exception directly from your code.
```java
@GetMapping("/users/{id}")
public User getUser(@PathVariable Long id) {
    return userRepository.findById(id)
        .orElseThrow(() -> new ResponseStatusException(
            HttpStatus.NOT_FOUND, "User not found with id: " + id));
}
```

### 12. What is Spring Data JPA and what are its benefits?

**Answer:** Spring Data JPA is a part of the larger Spring Data family that makes it easy to implement JPA-based repositories. It provides a high-level abstraction over JPA and reduces the amount of boilerplate code required to implement data access layers.

**Benefits:**
- Reduces boilerplate code for repository implementations
- Provides CRUD operations out of the box
- Supports dynamic query generation from method names
- Supports custom query methods using @Query
- Provides pagination and sorting capabilities
- Integrates with Spring's transaction management

Example:
```java
public interface UserRepository extends JpaRepository<User, Long> {
    // Derived query method - Spring Data JPA will generate the implementation
    List<User> findByLastName(String lastName);
    
    // Custom query using JPQL
    @Query("SELECT u FROM User u WHERE u.email = :email")
    Optional<User> findByEmail(@Param("email") String email);
}
```

### 13. What is the difference between `@RequestParam` and `@PathVariable`?

**Answer:** Both `@RequestParam` and `@PathVariable` are used to extract values from the HTTP request, but they are used in different scenarios:

- `@RequestParam` is used to extract query parameters from the URL or form data from POST requests.
  ```java
  // URL: /users?page=1&size=10
  @GetMapping("/users")
  public List<User> getUsers(@RequestParam(defaultValue = "0") int page, 
                            @RequestParam(defaultValue = "10") int size) {
      return userService.findAll(page, size);
  }
  ```

- `@PathVariable` is used to extract values from the URI path.
  ```java
  // URL: /users/123
  @GetMapping("/users/{id}")
  public User getUser(@PathVariable Long id) {
      return userService.findById(id);
  }
  ```

### 14. How do you implement validation in a Spring Boot application?

**Answer:** Spring Boot integrates with Bean Validation (JSR-380) to provide validation capabilities. Here's how to implement validation:

1. Add the validation starter dependency:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>
```

2. Add validation annotations to your model class:
```java
public class UserRequest {
    @NotBlank(message = "Name is required")
    private String name;
    
    @Email(message = "Email should be valid")
    @NotBlank(message = "Email is required")
    private String email;
    
    @Size(min = 8, message = "Password must be at least 8 characters long")
    private String password;
    
    // Getters and setters
}
```

3. Use the `@Valid` annotation in your controller:
```java
@PostMapping("/users")
public ResponseEntity<User> createUser(@Valid @RequestBody UserRequest request) {
    User user = userService.createUser(request);
    return ResponseEntity.status(HttpStatus.CREATED).body(user);
}
```

4. Implement exception handling for validation errors:
```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
```

### 15. What is the Spring Boot DevTools and how does it help in development?

**Answer:** Spring Boot DevTools is a set of tools that aims to make the development experience more pleasant. It includes:

1. **Automatic restart**: When files on the classpath change, DevTools automatically restarts your application. It uses two classloaders: one for your application and one for libraries. When code changes, only the application classloader is restarted, which is much faster than a full restart.

2. **LiveReload**: DevTools includes a built-in LiveReload server that can trigger a browser refresh when resources change.

3. **Property defaults**: DevTools sets sensible development-time properties, like disabling template caching.

4. **Remote debugging**: DevTools supports remote debugging via HTTP.

To use DevTools, add the dependency:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
    <optional>true</optional>
</dependency>
```

DevTools is automatically disabled when running a packaged application (i.e., `java -jar`).

## Microservices Interview Questions

### 1. What are microservices and how do they differ from a monolithic architecture?

**Answer:** Microservices is an architectural style that structures an application as a collection of small, loosely coupled services, each implementing a specific business capability. Each service runs in its own process and communicates with other services through lightweight mechanisms, typically HTTP/REST APIs.

**Differences from monolithic architecture:**

| Monolithic Architecture | Microservices Architecture |
|-------------------------|----------------------------|
| Single, unified codebase | Multiple codebases, one per service |
| Single deployment unit | Multiple deployment units |
| Tightly coupled components | Loosely coupled services |
| Shared database | Database per service |
| Scaling requires replicating the entire application | Services can be scaled independently |
| Single technology stack | Polyglot (can use different technologies) |
| Simpler to develop initially | More complex to develop initially |
| More difficult to maintain as it grows | Easier to maintain as it grows |
| Limited fault isolation | Better fault isolation |

### 2. What are the advantages and disadvantages of microservices?

**Answer:**

**Advantages:**
1. **Independent Deployment**: Services can be deployed independently, enabling faster releases and reducing risk.
2. **Technology Diversity**: Different services can use different technologies, languages, and frameworks.
3. **Scalability**: Services can be scaled independently based on their specific requirements.
4. **Resilience**: Failure in one service doesn't necessarily affect others.
5. **Team Autonomy**: Smaller teams can own and develop services independently.
6. **Easier Maintenance**: Smaller codebases are easier to understand and maintain.
7. **Better Alignment with Business**: Services are organized around business capabilities.

**Disadvantages:**
1. **Increased Complexity**: Distributed systems are inherently more complex.
2. **Network Latency**: Communication between services introduces network latency.
3. **Data Consistency**: Maintaining data consistency across services is challenging.
4. **Testing Complexity**: Testing interactions between services is more difficult.
5. **Operational Overhead**: More services mean more components to deploy, monitor, and manage.
6. **Development Environment**: Setting up a local development environment can be challenging.
7. **Debugging Challenges**: Tracing issues across multiple services is more complex.

### 3. What is the role of an API Gateway in a microservices architecture?

**Answer:** An API Gateway is a server that acts as an API front-end, receiving API requests, enforcing throttling and security policies, passing requests to the back-end service, and then passing the response back to the requester.

**Key responsibilities:**
1. **Routing**: Directs requests to the appropriate microservice.
2. **Aggregation**: Combines results from multiple microservices into a single response.
3. **Protocol Translation**: Translates between web protocols (e.g., HTTP, WebSocket) and internal protocols.
4. **Authentication and Authorization**: Centralizes security concerns.
5. **Rate Limiting and Throttling**: Protects services from being overwhelmed.
6. **Monitoring and Analytics**: Provides insights into API usage.
7. **Caching**: Improves performance by caching responses.
8. **Load Balancing**: Distributes traffic across multiple instances of services.

Popular API Gateway implementations include Spring Cloud Gateway, Netflix Zuul, Kong, and AWS API Gateway.

### 4. What is Service Discovery and why is it important in microservices?

**Answer:** Service Discovery is a mechanism that allows services to find and communicate with each other without hardcoding hostname and port information. It's crucial in a microservices architecture because:

1. **Dynamic Environments**: In cloud environments, services can be dynamically created, destroyed, or scaled, changing their network locations.
2. **Resilience**: It helps in routing around failed instances.
3. **Load Balancing**: It can distribute traffic across multiple instances of a service.

There are two main patterns for service discovery:
1. **Client-side Discovery**: The client queries a service registry to find the location of a service.
2. **Server-side Discovery**: A router (like a load balancer) queries the service registry and forwards the request.

Popular service discovery tools include:
- Netflix Eureka
- Consul
- etcd
- ZooKeeper
- Kubernetes Service Discovery

### 5. What is the Circuit Breaker pattern and why is it used in microservices?

**Answer:** The Circuit Breaker pattern is a design pattern used to detect failures and prevent cascading failures in distributed systems. It works like an electrical circuit breaker:

1. **Closed State**: In normal operation, the circuit is closed, and requests pass through to the service.
2. **Open State**: If the number of failures exceeds a threshold, the circuit opens, and requests fail fast without attempting to call the service.
3. **Half-Open State**: After a timeout period, the circuit transitions to half-open, allowing a limited number of test requests to pass through. If these succeed, the circuit closes; if they fail, it opens again.

**Why it's used:**
- **Prevents Cascading Failures**: If one service is slow or failing, it won't bring down the entire system.
- **Fail Fast**: When a service is unavailable, requests fail immediately rather than waiting for timeouts.
- **Graceful Degradation**: Systems can provide fallback responses when services are unavailable.
- **Self-Healing**: The circuit can automatically close when the service recovers.

Popular implementations include:
- Resilience4j
- Hystrix (now in maintenance mode)
- Sentinel

### 6. How do you handle data consistency in a microservices architecture?

**Answer:** Data consistency in microservices is challenging because each service typically has its own database. There are several approaches to handle this:

1. **Eventual Consistency**: Accept that data will be consistent eventually rather than immediately. This is often implemented using event-driven architecture.

2. **Saga Pattern**: Coordinate a series of local transactions, each updating data within a single service. If a step fails, compensating transactions are executed to undo previous changes.
   - **Choreography**: Services publish events when they update data, and other services listen for these events.
   - **Orchestration**: A central coordinator directs the saga, telling each service when to execute local transactions.

3. **Two-Phase Commit (2PC)**: A distributed transaction protocol that ensures all services either commit or roll back their transactions. However, it's generally avoided in microservices due to its synchronous nature and potential for blocking.

4. **CQRS (Command Query Responsibility Segregation)**: Separate read and write operations, allowing for different data models optimized for each purpose.

5. **Event Sourcing**: Store all changes to application state as a sequence of events, which can be replayed to reconstruct the state.

6. **Database per Service with Replication**: Each service has its own database, but data is replicated to other services that need it.

The choice depends on the specific requirements of your application, particularly the balance between consistency, availability, and partition tolerance (CAP theorem).

### 7. What is the Saga pattern and how is it implemented?

**Answer:** The Saga pattern is a way to manage data consistency across microservices in distributed transactions. A saga is a sequence of local transactions where each transaction updates data within a single service. If a transaction fails, compensating transactions are executed to undo the changes made by the preceding transactions.

There are two main ways to implement the Saga pattern:

1. **Choreography-based Saga**:
   - Each service publishes domain events when it performs a local transaction.
   - Other services listen for these events and perform their local transactions in response.
   - If a service fails, it publishes a failure event, and services that already executed transactions perform compensating actions.

   ```java
   // Order Service
   @Transactional
   public Order createOrder(OrderRequest request) {
       Order order = new Order(request);
       orderRepository.save(order);
       eventPublisher.publish(new OrderCreatedEvent(order.getId(), order.getAmount()));
       return order;
   }
   
   // Payment Service
   @EventListener
   public void handleOrderCreated(OrderCreatedEvent event) {
       try {
           Payment payment = paymentService.processPayment(event.getOrderId(), event.getAmount());
           eventPublisher.publish(new PaymentCompletedEvent(event.getOrderId(), payment.getId()));
       } catch (Exception e) {
           eventPublisher.publish(new PaymentFailedEvent(event.getOrderId(), e.getMessage()));
       }
   }
   
   // Order Service (compensation)
   @EventListener
   public void handlePaymentFailed(PaymentFailedEvent event) {
       Order order = orderRepository.findById(event.getOrderId()).orElseThrow();
       order.setStatus(OrderStatus.PAYMENT_FAILED);
       orderRepository.save(order);
   }
   ```

2. **Orchestration-based Saga**:
   - A central orchestrator (a service or component) directs the saga participants and determines the next steps.
   - The orchestrator maintains the state of the saga and invokes compensating transactions when needed.

   ```java
   @Service
   public class OrderSagaOrchestrator {
       private final OrderService orderService;
       private final PaymentService paymentService;
       private final InventoryService inventoryService;
       private final ShippingService shippingService;
       
       @Transactional
       public OrderResult createOrder(OrderRequest request) {
           // Step 1: Create Order
           Order order = orderService.createOrder(request);
           
           try {
               // Step 2: Process Payment
               Payment payment = paymentService.processPayment(order.getId(), order.getAmount());
               
               try {
                   // Step 3: Reserve Inventory
                   inventoryService.reserveItems(order.getId(), order.getItems());
                   
                   try {
                       // Step 4: Schedule Shipping
                       Shipment shipment = shippingService.scheduleShipment(order.getId(), order.getAddress());
                       return new OrderResult(order, payment, shipment);
                   } catch (Exception e) {
                       // Compensate Step 3
                       inventoryService.releaseItems(order.getId(), order.getItems());
                       // Compensate Step 2
                       paymentService.refundPayment(payment.getId());
                       // Compensate Step 1
                       orderService.cancelOrder(order.getId());
                       throw e;
                   }
               } catch (Exception e) {
                   // Compensate Step 2
                   paymentService.refundPayment(payment.getId());
                   // Compensate Step 1
                   orderService.cancelOrder(order.getId());
                   throw e;
               }
           } catch (Exception e) {
               // Compensate Step 1
               orderService.cancelOrder(order.getId());
               throw e;
           }
       }
   }
   ```

The choice between choreography and orchestration depends on the complexity of the transaction and the relationships between services. Choreography is more decentralized and flexible but can be harder to track, while orchestration provides better visibility and control but can become a bottleneck.

### 8. What is the difference between synchronous and asynchronous communication in microservices?

**Answer:** In microservices architecture, services can communicate with each other using either synchronous or asynchronous communication patterns:

**Synchronous Communication:**
- The client sends a request and waits for a response before continuing.
- Typically implemented using REST APIs or gRPC.
- The client is blocked until it receives a response or times out.
- Simpler to implement and understand.
- Creates tighter coupling between services.
- Can lead to cascading failures if one service is slow or down.

Example (REST API):
```java
@RestController
public class OrderController {
    private final PaymentServiceClient paymentServiceClient;
    
    @PostMapping("/orders")
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest request) {
        // Create order
        Order order = orderService.createOrder(request);
        
        // Call payment service synchronously
        PaymentResponse paymentResponse = paymentServiceClient.processPayment(
            new PaymentRequest(order.getId(), order.getAmount())
        );
        
        // Update order with payment information
        order.setPaymentId(paymentResponse.getPaymentId());
        order.setStatus(OrderStatus.PAID);
        orderService.updateOrder(order);
        
        return ResponseEntity.ok(order);
    }
}
```

**Asynchronous Communication:**
- The client sends a request and continues processing without waiting for a response.
- Typically implemented using message brokers (e.g., Kafka, RabbitMQ) or event streams.
- The client is not blocked and can continue processing.
- More complex to implement and understand.
- Creates looser coupling between services.
- Better resilience to service failures.
- Better scalability as services can process messages at their own pace.

Example (Kafka):
```java
@Service
public class OrderService {
    private final KafkaTemplate<String, OrderCreatedEvent> kafkaTemplate;
    
    @Transactional
    public Order createOrder(OrderRequest request) {
        // Create order
        Order order = new Order(request);
        orderRepository.save(order);
        
        // Publish event asynchronously
        kafkaTemplate.send("order-events", new OrderCreatedEvent(
            order.getId(), order.getUserId(), order.getAmount()
        ));
        
        return order;
    }
}

// In Payment Service
@Service
public class PaymentEventListener {
    @KafkaListener(topics = "order-events")
    public void handleOrderCreatedEvent(OrderCreatedEvent event) {
        // Process payment
        Payment payment = paymentService.processPayment(
            event.getOrderId(), event.getAmount()
        );
        
        // Publish payment completed event
        kafkaTemplate.send("payment-events", new PaymentCompletedEvent(
            event.getOrderId(), payment.getId()
        ));
    }
}
```

In practice, most microservices architectures use a combination of both patterns, choosing the appropriate one based on the specific use case.

### 9. How do you implement authentication and authorization in a microservices architecture?

**Answer:** Implementing authentication and authorization in a microservices architecture involves several approaches:

1. **API Gateway Authentication**:
   - The API Gateway authenticates all incoming requests.
   - It validates tokens/credentials and passes identity information to downstream services.
   - This centralizes authentication logic and reduces duplication.

2. **Token-based Authentication (JWT/OAuth2)**:
   - Clients authenticate against an identity provider and receive a token.
   - The token is passed with each request to services.
   - Services validate the token and extract identity information.
   - OAuth2 with JWT is a common implementation.

3. **Service-to-Service Authentication**:
   - Services authenticate with each other using client credentials, certificates, or tokens.
   - Mutual TLS (mTLS) can be used for secure service-to-service communication.

4. **Authorization Strategies**:
   - **Centralized**: Authorization decisions are made by a dedicated authorization service.
   - **Decentralized**: Each service makes its own authorization decisions based on the user's identity and permissions.
   - **Policy-based**: Authorization decisions are based on policies (e.g., RBAC, ABAC).

Example implementation with Spring Security and OAuth2:

```java
// API Gateway Configuration
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        http
            .authorizeExchange()
                .pathMatchers("/public/**").permitAll()
                .anyExchange().authenticated()
                .and()
            .oauth2ResourceServer()
                .jwt();
        return http.build();
    }
}

// Microservice Configuration
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
                .antMatchers("/actuator/**").permitAll()
                .anyRequest().authenticated()
                .and()
            .oauth2ResourceServer()
                .jwt();
    }
}

// Service-to-Service Authentication
@Configuration
public class RestTemplateConfig {
    
    @Bean
    public RestTemplate restTemplate(OAuth2AuthorizedClientManager authorizedClientManager) {
        OAuth2AuthorizedClientService clientService = new InMemoryOAuth2AuthorizedClientService(
            clientRegistrationRepository()
        );
        
        OAuth2AuthorizedClientManager manager = new DefaultOAuth2AuthorizedClientManager(
            clientRegistrationRepository(), clientService
        );
        
        OAuth2AuthorizedClientProvider provider = OAuth2AuthorizedClientProviderBuilder.builder()
            .clientCredentials()
            .build();
        
        manager.setAuthorizedClientProvider(provider);
        
        return new RestTemplateBuilder()
            .additionalInterceptors(new OAuth2AuthorizedClientInterceptor(manager))
            .build();
    }
}
```

### 10. What is the role of a Config Server in microservices?

**Answer:** A Config Server in a microservices architecture provides a centralized place to manage external properties for applications across all environments. It serves several important roles:

1. **Centralized Configuration**: Stores configuration for all services in a single place, making it easier to manage.

2. **Environment-specific Configuration**: Allows different configurations for different environments (dev, test, prod).

3. **Runtime Configuration Changes**: Enables changing configuration at runtime without redeploying services.

4. **Version Control**: Configuration can be stored in a version control system (e.g., Git), providing history and auditability.

5. **Encryption/Decryption**: Sensitive configuration values can be encrypted.

Spring Cloud Config Server is a popular implementation that integrates well with Spring Boot applications:

```java
// Config Server
@SpringBootApplication
@EnableConfigServer
public class ConfigServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
    }
}

// application.yml for Config Server
server:
  port: 8888
spring:
  cloud:
    config:
      server:
        git:
          uri: https://github.com/myorg/config-repo
          search-paths: '{application}'
          default-label: main

// Client Service
@SpringBootApplication
@EnableConfigClient
public class OrderServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
}

// bootstrap.yml for Client Service
spring:
  application:
    name: order-service
  cloud:
    config:
      uri: http://config-server:8888
      fail-fast: true
```

With this setup, the Order Service will fetch its configuration from the Config Server, which retrieves it from the Git repository.

### 11. How do you monitor and trace requests in a microservices architecture?

**Answer:** Monitoring and tracing requests in a microservices architecture involves several techniques and tools:

1. **Distributed Tracing**:
   - Assigns a unique ID to each request as it enters the system.
   - Tracks the request as it flows through different services.
   - Helps identify bottlenecks and troubleshoot issues.
   - Tools: Zipkin, Jaeger, Spring Cloud Sleuth.

   ```java
   // Spring Cloud Sleuth configuration
   @SpringBootApplication
   public class OrderServiceApplication {
       public static void main(String[] args) {
           SpringApplication.run(OrderServiceApplication.class, args);
       }
   }
   
   // application.yml
   spring:
     sleuth:
       sampler:
         probability: 1.0
     zipkin:
       base-url: http://zipkin-server:9411/
   ```

2. **Centralized Logging**:
   - Aggregates logs from all services in a central location.
   - Allows correlation of logs across services.
   - Tools: ELK Stack (Elasticsearch, Logstash, Kibana), Graylog, Fluentd.

   ```java
   // Logback configuration for ELK
   <appender name="LOGSTASH" class="net.logstash.logback.appender.LogstashTcpSocketAppender">
       <destination>logstash-server:5000</destination>
       <encoder class="net.logstash.logback.encoder.LogstashEncoder">
           <includeMdc>true</includeMdc>
           <customFields>{"app_name":"order-service"}</customFields>
       </encoder>
   </appender>
   ```

3. **Metrics Collection**:
   - Collects performance metrics from services.
   - Monitors resource usage, response times, error rates, etc.
   - Tools: Prometheus, Grafana, Micrometer.

   ```java
   // Micrometer configuration
   @Bean
   public MeterRegistryCustomizer<MeterRegistry> metricsCommonTags() {
       return registry -> registry.config().commonTags("application", "order-service");
   }
   
   // Custom metrics
   @RestController
   public class OrderController {
       private final Counter orderCounter;
       private final Timer orderTimer;
       
       public OrderController(MeterRegistry registry) {
           this.orderCounter = registry.counter("orders.created");
           this.orderTimer = registry.timer("orders.creation.time");
       }
       
       @PostMapping("/orders")
       public ResponseEntity<Order> createOrder(@RequestBody OrderRequest request) {
           return orderTimer.record(() -> {
               Order order = orderService.createOrder(request);
               orderCounter.increment();
               return ResponseEntity.status(HttpStatus.CREATED).body(order);
           });
       }
   }
   ```

4. **Health Checks**:
   - Monitors the health of services and their dependencies.
   - Provides information about service availability.
   - Tools: Spring Boot Actuator, Kubernetes liveness/readiness probes.

   ```java
   // Custom health indicator
   @Component
   public class DatabaseHealthIndicator implements HealthIndicator {
       private final DataSource dataSource;
       
       public DatabaseHealthIndicator(DataSource dataSource) {
           this.dataSource = dataSource;
       }
       
       @Override
       public Health health() {
           try (Connection conn = dataSource.getConnection()) {
               PreparedStatement ps = conn.prepareStatement("SELECT 1");
               ps.executeQuery();
               return Health.up().build();
           } catch (Exception e) {
               return Health.down().withException(e).build();
           }
       }
   }
   ```

5. **Service Mesh**:
   - Provides infrastructure layer for service-to-service communication.
   - Offers features like traffic management, security, and observability.
   - Tools: Istio, Linkerd, Consul Connect.

A comprehensive monitoring solution typically combines all these approaches to provide a complete view of the system's health and performance.

### 12. What is the Database per Service pattern and what are its trade-offs?

**Answer:** The Database per Service pattern is a microservices data architecture where each service has its own database, and the database is only accessible by that service. Other services cannot access it directly.

**Benefits:**
1. **Loose Coupling**: Services are decoupled at the data level, allowing them to evolve independently.
2. **Technology Flexibility**: Each service can use the database technology that best suits its needs (SQL, NoSQL, etc.).
3. **Independent Scaling**: Databases can be scaled according to the specific needs of each service.
4. **Improved Fault Isolation**: A database failure affects only one service.
5. **Clear Ownership**: Each team owns and is responsible for their service's data.

**Trade-offs:**
1. **Data Consistency Challenges**: Maintaining consistency across services becomes more complex.
2. **Distributed Transactions**: Traditional ACID transactions across services are difficult to implement.
3. **Complexity in Queries**: Joining data across services requires additional API calls or event-driven mechanisms.
4. **Operational Overhead**: Managing multiple databases increases operational complexity.
5. **Data Duplication**: Some data may need to be duplicated across services.

**Implementation Approaches:**
1. **Event-Driven Architecture**: Services publish events when their data changes, and other services update their data accordingly.
2. **Saga Pattern**: Coordinate a series of local transactions to maintain consistency.
3. **CQRS**: Separate read and write operations, allowing for different data models.
4. **API Composition**: Aggregate data from multiple services at the API level.

Example implementation with Spring Boot:

```java
// Order Service Database Configuration
@Configuration
@EnableJpaRepositories(basePackages = "com.example.orderservice.repository")
@EntityScan(basePackages = "com.example.orderservice.model")
public class OrderDatabaseConfig {
    
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }
}

// application.yml for Order Service
spring:
  datasource:
    url: jdbc:mysql://order-db:3306/orderdb
    username: order_user
    password: order_pass
  jpa:
    hibernate:
      ddl-auto: update

// User Service Database Configuration
@Configuration
@EnableJpaRepositories(basePackages = "com.example.userservice.repository")
@EntityScan(basePackages = "com.example.userservice.model")
public class UserDatabaseConfig {
    
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }
}

// application.yml for User Service
spring:
  datasource:
    url: jdbc:postgresql://user-db:5432/userdb
    username: user_user
    password: user_pass
  jpa:
    hibernate:
      ddl-auto: update
```

### 13. What is CQRS (Command Query Responsibility Segregation) and when would you use it?

**Answer:** CQRS (Command Query Responsibility Segregation) is an architectural pattern that separates read and write operations for a data store. Instead of having a single model for both commands (writes) and queries (reads), CQRS uses separate models:

1. **Command Model**: Handles create, update, and delete operations (writes).
2. **Query Model**: Handles read operations, often with denormalized data optimized for specific queries.

**When to use CQRS:**

1. **High-Performance Read Requirements**: When read operations have different performance requirements than write operations.
2. **Complex Domain Logic**: When the domain logic for updates is complex but read operations are simple.
3. **Different Scaling Needs**: When read and write operations need to scale differently.
4. **Event Sourcing**: When combined with event sourcing to capture all changes to application state.
5. **Collaborative Domains**: When multiple users might be updating the same data concurrently.

**When not to use CQRS:**

1. **Simple CRUD Applications**: For basic CRUD applications, CQRS adds unnecessary complexity.
2. **Small Applications**: The overhead may not be justified for small applications.
3. **Limited Resources**: When development resources are constrained, as CQRS requires more code and infrastructure.

Example implementation with Spring Boot:

```java
// Command Model
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long userId;
    private BigDecimal totalAmount;
    
    @Enumerated(EnumType.STRING)
    private OrderStatus status;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "order")
    private List<OrderItem> items = new ArrayList<>();
    
    // Getters and setters
}

// Command Service
@Service
public class OrderCommandService {
    
    private final OrderRepository orderRepository;
    private final EventPublisher eventPublisher;
    
    @Transactional
    public Order createOrder(OrderRequest request) {
        Order order = new Order();
        order.setUserId(request.getUserId());
        order.setTotalAmount(request.getTotalAmount());
        order.setStatus(OrderStatus.CREATED);
        
        // Add items
        request.getItems().forEach(item -> {
            OrderItem orderItem = new OrderItem();
            orderItem.setProductId(item.getProductId());
            orderItem.setQuantity(item.getQuantity());
            orderItem.setPrice(item.getPrice());
            orderItem.setOrder(order);
            order.getItems().add(orderItem);
        });
        
        Order savedOrder = orderRepository.save(order);
        
        // Publish event for query model update
        eventPublisher.publish(new OrderCreatedEvent(savedOrder));
        
        return savedOrder;
    }
}

// Query Model (Denormalized)
@Document(collection = "order_summaries")
public class OrderSummary {
    @Id
    private String id;
    
    private Long orderId;
    private Long userId;
    private String userName;
    private BigDecimal totalAmount;
    private OrderStatus status;
    private List<OrderItemSummary> items = new ArrayList<>();
    private LocalDateTime createdAt;
    
    // Getters and setters
}

// Query Service
@Service
public class OrderQueryService {
    
    private final OrderSummaryRepository orderSummaryRepository;
    
    public OrderSummary getOrderSummary(Long orderId) {
        return orderSummaryRepository.findByOrderId(orderId)
            .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }
    
    public List<OrderSummary> getOrdersByUserId(Long userId) {
        return orderSummaryRepository.findByUserId(userId);
    }
}

// Event Handler to Update Query Model
@Service
public class OrderEventHandler {
    
    private final OrderSummaryRepository orderSummaryRepository;
    private final UserServiceClient userServiceClient;
    
    @EventListener
    public void handleOrderCreatedEvent(OrderCreatedEvent event) {
        Order order = event.getOrder();
        
        // Get user details
        User user = userServiceClient.getUserById(order.getUserId());
        
        // Create order summary
        OrderSummary summary = new OrderSummary();
        summary.setOrderId(order.getId());
        summary.setUserId(order.getUserId());
        summary.setUserName(user.getName());
        summary.setTotalAmount(order.getTotalAmount());
        summary.setStatus(order.getStatus());
        summary.setCreatedAt(LocalDateTime.now());
        
        // Add items
        order.getItems().forEach(item -> {
            OrderItemSummary itemSummary = new OrderItemSummary();
            itemSummary.setProductId(item.getProductId());
            itemSummary.setQuantity(item.getQuantity());
            itemSummary.setPrice(item.getPrice());
            summary.getItems().add(itemSummary);
        });
        
        orderSummaryRepository.save(summary);
    }
}
```

### 14. What is Event Sourcing and how does it relate to microservices?

**Answer:** Event Sourcing is a pattern where changes to application state are stored as a sequence of events. Instead of storing just the current state, you store the history of actions that led to that state. The current state can be reconstructed by replaying these events.

**Key concepts:**
1. **Events**: Immutable records of something that happened in the system.
2. **Event Store**: A database that stores the sequence of events.
3. **Projections**: Views of the data derived from the events, optimized for specific queries.
4. **Snapshots**: Periodic captures of the current state to optimize reconstruction.

**Relation to microservices:**
1. **Decoupling**: Event Sourcing naturally fits with event-driven microservices, allowing services to react to events.
2. **Data Consistency**: Helps maintain consistency across services by providing a single source of truth.
3. **Audit Trail**: Provides a complete history of all changes, which is valuable for compliance and debugging.
4. **Temporal Queries**: Enables querying the state of the system at any point in time.
5. **Event Replay**: Allows rebuilding state or creating new projections by replaying events.

Example implementation with Spring Boot and Axon Framework:

```java
// Aggregate Root
@Aggregate
public class Order {
    @AggregateIdentifier
    private String id;
    private Long userId;
    private BigDecimal totalAmount;
    private OrderStatus status;
    private List<OrderItem> items = new ArrayList<>();
    
    @CommandHandler
    public Order(CreateOrderCommand command) {
        apply(new OrderCreatedEvent(
            command.getOrderId(),
            command.getUserId(),
            command.getTotalAmount()
        ));
    }
    
    @EventSourcingHandler
    public void on(OrderCreatedEvent event) {
        this.id = event.getOrderId();
        this.userId = event.getUserId();
        this.totalAmount = event.getTotalAmount();
        this.status = OrderStatus.CREATED;
    }
    
    @CommandHandler
    public void handle(AddOrderItemCommand command) {
        apply(new OrderItemAddedEvent(
            id,
            command.getProductId(),
            command.getQuantity(),
            command.getPrice()
        ));
    }
    
    @EventSourcingHandler
    public void on(OrderItemAddedEvent event) {
        OrderItem item = new OrderItem();
        item.setProductId(event.getProductId());
        item.setQuantity(event.getQuantity());
        item.setPrice(event.getPrice());
        this.items.add(item);
    }
    
    // More command handlers and event sourcing handlers
}

// Command
public class CreateOrderCommand {
    @TargetAggregateIdentifier
    private final String orderId;
    private final Long userId;
    private final BigDecimal totalAmount;
    
    // Constructor, getters
}

// Event
public class OrderCreatedEvent {
    private final String orderId;
    private final Long userId;
    private final BigDecimal totalAmount;
    
    // Constructor, getters
}

// Query Model
@Entity
@Table(name = "order_view")
public class OrderView {
    @Id
    private String id;
    private Long userId;
    private BigDecimal totalAmount;
    private OrderStatus status;
    
    // Getters and setters
}

// Event Handler for Query Model
@Component
public class OrderEventHandler {
    
    private final OrderViewRepository repository;
    
    @EventHandler
    public void on(OrderCreatedEvent event) {
        OrderView view = new OrderView();
        view.setId(event.getOrderId());
        view.setUserId(event.getUserId());
        view.setTotalAmount(event.getTotalAmount());
        view.setStatus(OrderStatus.CREATED);
        repository.save(view);
    }
    
    @EventHandler
    public void on(OrderItemAddedEvent event) {
        // Update order view
    }
    
    // More event handlers
}
```

### 15. How do you test microservices?

**Answer:** Testing microservices requires a comprehensive approach that covers different levels of testing:

1. **Unit Testing**:
   - Tests individual components in isolation.
   - Mocks external dependencies.
   - Fast and focused.

   ```java
   @ExtendWith(MockitoExtension.class)
   public class OrderServiceTest {
       
       @Mock
       private OrderRepository orderRepository;
       
       @InjectMocks
       private OrderServiceImpl orderService;
       
       @Test
       public void testCreateOrder() {
           // Arrange
           OrderRequest request = new OrderRequest(1L, new BigDecimal("100.00"));
           Order order = new Order();
           order.setId(1L);
           order.setUserId(1L);
           order.setTotalAmount(new BigDecimal("100.00"));
           
           when(orderRepository.save(any(Order.class))).thenReturn(order);
           
           // Act
           Order result = orderService.createOrder(request);
           
           // Assert
           assertEquals(1L, result.getId());
           assertEquals(new BigDecimal("100.00"), result.getTotalAmount());
           verify(orderRepository).save(any(Order.class));
       }
   }
   ```

2. **Integration Testing**:
   - Tests the interaction between components.
   - May involve databases, message brokers, etc.
   - Slower than unit tests but more comprehensive.

   ```java
   @SpringBootTest
   @AutoConfigureMockMvc
   public class OrderControllerIntegrationTest {
       
       @Autowired
       private MockMvc mockMvc;
       
       @Autowired
       private ObjectMapper objectMapper;
       
       @MockBean
       private PaymentServiceClient paymentServiceClient;
       
       @Test
       public void testCreateOrder() throws Exception {
           // Arrange
           OrderRequest request = new OrderRequest(1L, new BigDecimal("100.00"));
           PaymentResponse paymentResponse = new PaymentResponse(true, "12345");
           
           when(paymentServiceClient.processPayment(any())).thenReturn(paymentResponse);
           
           // Act & Assert
           mockMvc.perform(post("/api/orders")
                   .contentType(MediaType.APPLICATION_JSON)
                   .content(objectMapper.writeValueAsString(request)))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.userId").value(1))
               .andExpect(jsonPath("$.totalAmount").value(100.00))
               .andExpect(jsonPath("$.status").value("PAID"));
       }
   }
   ```

3. **Contract Testing**:
   - Ensures that services can communicate with each other as expected.
   - Verifies that the API contract is maintained.
   - Tools: Spring Cloud Contract, Pact.

   ```java
   // Consumer-Driven Contract Testing with Spring Cloud Contract
   @RunWith(SpringRunner.class)
   @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
   @AutoConfigureStubRunner(
       ids = {"com.example:payment-service:+:stubs:8080"},
       stubsMode = StubRunnerProperties.StubsMode.LOCAL
   )
   public class PaymentServiceContractTest {
       
       @Autowired
       private PaymentServiceClient paymentServiceClient;
       
       @Test
       public void testProcessPayment() {
           // Arrange
           PaymentRequest request = new PaymentRequest(1L, new BigDecimal("100.00"));
           
           // Act
           PaymentResponse response = paymentServiceClient.processPayment(request);
           
           // Assert
           assertTrue(response.isSuccess());
           assertNotNull(response.getPaymentId());
       }
   }
   ```

4. **Component Testing**:
   - Tests a single service in isolation.
   - Mocks external dependencies.
   - Focuses on the service's API contract.

   ```java
   @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
   public class OrderServiceComponentTest {
       
       @Autowired
       private TestRestTemplate restTemplate;
       
       @MockBean
       private PaymentServiceClient paymentServiceClient;
       
       @Test
       public void testCreateOrder() {
           // Arrange
           OrderRequest request = new OrderRequest(1L, new BigDecimal("100.00"));
           PaymentResponse paymentResponse = new PaymentResponse(true, "12345");
           
           when(paymentServiceClient.processPayment(any())).thenReturn(paymentResponse);
           
           // Act
           ResponseEntity<Order> response = restTemplate.postForEntity(
               "/api/orders", request, Order.class);
           
           // Assert
           assertEquals(HttpStatus.CREATED, response.getStatusCode());
           assertNotNull(response.getBody());
           assertEquals(1L, response.getBody().getUserId());
       }
   }
   ```

5. **End-to-End Testing**:
   - Tests the entire system as a whole.
   - Verifies that all services work together correctly.
   - Slowest but most comprehensive.

   ```java
   @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
   public class OrderEndToEndTest {
       
       @Autowired
       private TestRestTemplate restTemplate;
       
       @Test
       public void testCreateOrderEndToEnd() {
           // Arrange
           OrderRequest request = new OrderRequest(1L, new BigDecimal("100.00"));
           
           // Act
           ResponseEntity<Order> response = restTemplate.postForEntity(
               "/api/orders", request, Order.class);
           
           // Assert
           assertEquals(HttpStatus.CREATED, response.getStatusCode());
           assertNotNull(response.getBody());
           
           // Verify order was created
           ResponseEntity<Order> getResponse = restTemplate.getForEntity(
               "/api/orders/{id}", Order.class, response.getBody().getId());
           
           assertEquals(HttpStatus.OK, getResponse.getStatusCode());
           assertEquals(response.getBody().getId(), getResponse.getBody().getId());
       }
   }
   ```

6. **Performance Testing**:
   - Tests the performance characteristics of services.
   - Identifies bottlenecks and scalability issues.
   - Tools: JMeter, Gatling.

7. **Chaos Testing**:
   - Deliberately introduces failures to test resilience.
   - Verifies that the system can handle unexpected conditions.
   - Tools: Chaos Monkey, Gremlin.

A comprehensive testing strategy for microservices should include all these levels, with a focus on automation to enable continuous integration and delivery.
